# CivicOS AI — Civic Intelligence & Municipal Action

A modern, responsive civic-tech web platform for reporting, tracking, and resolving municipal infrastructure issues (garbage dumps, road potholes, water pipeline leakages, streetlight failures, and drainage hazards).

Target Repository: `https://github.com/Sanyojita07/civicos-ai`

---

## 🛠️ Tech Stack & Architecture

- **Frontend Framework**: React 18 with TypeScript
- **Build Tooling**: Vite with strict TypeScript checking (`strict: true`, `noUnusedLocals: true`, `noUnusedParameters: true`)
- **Styling**: Tailwind CSS with custom responsive layout systems and accessible motion keyframes
- **Backend & Database**: Supabase PostgreSQL (`@supabase/supabase-js`)
- **Security & Access Control**: Row Level Security (RLS) policies enforcing public read, authenticated insert, and guest anonymous insert with strict status lockdown
- **Icons**: Lucide React

### System Architecture Overview

```
+--------------------------------------------------------------------------+
|                            CivicOS AI (React + TS)                       |
+-------------------+--------------------+-------------------+-------------+
|    Navigation     |     Dashboard      |   Reporting Hub   |  Live Desk  |
| (Responsive Nav,  | (Overview KPIs,    | (Form Validation, | (Tracking,  |
|  Auth Modal)      |  Charts & Metrics) |  Duplicate Check) |  Explore)   |
+-------------------+--------------------+-------------------+-------------+
                                     |
              +----------------------+----------------------+
              |                                             |
     [Live Supabase Mode]                           [Demo Mode Fallback]
 (PostgreSQL via @supabase/supabase-js)         (Local Mock Dataset & Storage)
```

---

## 🚀 Getting Started

### 1. Install Dependencies

```bash
npm install
```

### 2. Configure Environment Variables

CivicOS AI supports seamless fallback into **Demo Mode** out of the box when credentials are not configured. To enable live database operations and authentication:

1. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
2. Populate the environment variables with your Supabase project keys:
   ```env
   VITE_SUPABASE_URL=https://your-project-id.supabase.co
   VITE_SUPABASE_PUBLISHABLE_KEY=your-anon-publishable-key
   ```

*Note: Environment variables are accessed strictly via `import.meta.env` and sanitized against whitespace and wrapping quotes.*

### 3. Setup Supabase Database

Execute the provided SQL script in your Supabase project's **SQL Editor** (`supabase-setup.sql`):

```sql
CREATE TABLE public.issues (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL CHECK (
        category IN ('Garbage', 'Pothole/Road', 'Water Leakage', 'Streetlight', 'Other')
    ),
    location TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Reported' CHECK (
        status IN ('Reported', 'In Progress', 'Resolved')
    ),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.issues ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON TABLE public.issues TO anon, authenticated;
REVOKE UPDATE, DELETE ON TABLE public.issues FROM anon, authenticated;

CREATE POLICY "Public read access"
ON public.issues FOR SELECT
TO anon, authenticated
USING (true);

CREATE POLICY "Authenticated secure insert"
ON public.issues FOR INSERT
TO authenticated
WITH CHECK (
    user_id = auth.uid()
    AND status = 'Reported'
);

CREATE POLICY "Guest anonymous insert"
ON public.issues FOR INSERT
TO anon
WITH CHECK (
    user_id IS NULL
    AND status = 'Reported'
);
```

### 4. Run Development Server

```bash
npm run dev
```

Visit `http://localhost:5173` in your browser.

---

## 📋 Features & Views

1. **Overview Dashboard**:
   - Live municipal triage KPI counters (Total Reports, Reported, In Progress, Resolved) with animated numeric count-ups.
   - Interactive SVG Status Donut Chart with hover tooltips and dynamic resolution rate.
   - Proportional Category Bar Chart with one-click filtering.
   - Submission activity timeline aggregating issues by calendar date.
   - Newest citizen reports feed with direct links to reporting.

2. **Report an Issue**:
   - Comprehensive form with category selection (`Garbage`, `Pothole/Road`, `Water Leakage`, `Streetlight`, `Other`).
   - Real-time client-side duplicate detection flagging potential matching complaints in the same category and vicinity before submission.
   - Instant reference confirmation banner displaying the assigned UUID with one-click clipboard copying.
   - Supports both authenticated users and anonymous guests (using browser `localStorage` under `guest_issue_ids`).

3. **Explore Reports**:
   - Interactive card directory with real-time multi-field search (matching across report title, description keywords, and location names like Lucknow, Aliganj, Gomti Nagar).
   - Category and lifecycle status filters with active filter badges and one-click filter reset.

4. **Tracking Reports**:
   - Live tracking desk allowing citizens to look up reports by unique Report ID UUID, title, or location.
   - Visual milestone timeline (`Reported` → `Under Review` → `In Progress` → `Resolved`) derived strictly from verified database records.

5. **My Reports**:
   - Personalized view for citizens: authenticated users view issues tied to their profile; guests view their session reports persisted in local browser storage.

6. **Community & Guidelines**:
   - Educational resource covering what can and cannot be reported, civic reporting best practices, personal privacy cautions, workflow expectations, and interactive FAQ accordions.

7. **Demo Mode Fallback**:
   - If Supabase environment variables are absent or invalid, the app gracefully runs in Demo Mode with mock sample records without crashing or throwing unhandled errors.

---

## 🧪 Available Build & Test Commands

| Command | Purpose |
| :--- | :--- |
| `npm run dev` | Starts Vite local development server on `localhost:5173` |
| `npx.cmd tsc --noEmit` | Runs strict TypeScript type-checking across all source files |
| `npm run build` | Runs full TypeScript compiler check followed by Vite production bundling into `dist/` |
| `npm run preview` | Serves the production build locally for verification |

---

## ⚠️ Known Limitations & Design Choices

- **Image Attachments**: Image uploads are intentionally not accepted in this MVP to prevent inappropriate content hosting and keep public infrastructure lightweight.
- **Administrative Status Transitions**: Issue statuses (`Reported` → `In Progress` → `Resolved`) are restricted by PostgreSQL Row Level Security (RLS) so that only authorized municipal administrators can change complaint statuses, preventing unauthorized status manipulation.
- **Guest History Scope**: Guest report history relies on local browser storage (`guest_issue_ids`). Clearing browser cookies or cache resets guest history, though records remain safely stored in the public registry.

---

## 🌐 Deployment Instructions

### Vercel / Netlify / Cloudflare Pages

1. Build the production bundle:
   ```bash
   npm run build
   ```
2. Set Build Command: `npm run build`
3. Set Output Directory: `dist`
4. Add Environment Variables in your hosting dashboard:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_KEY`

---

## 📄 License

This project is licensed under the [MIT License](LICENSE).
