/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        navy: "#0F172A",
        teal: {
          DEFAULT: "#0D9488",
          600: "#0D9488",
          700: "#0f766e",
          50: "#f0fdfa",
          100: "#ccfbf1",
        },
        lime: {
          DEFAULT: "#A3E635",
          400: "#A3E635",
          500: "#84cc16",
        },
        background: "#F8FAFC",
      },
    },
  },
  plugins: [],
}
