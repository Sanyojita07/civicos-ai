-- ==============================================================================
-- CivicOS AI - Supabase Database Schema & Row Level Security Setup
-- ==============================================================================
-- Safe & Idempotent Script: Can be run safely in your Supabase SQL Editor.
-- Non-destructive: Does NOT drop existing tables or delete existing records.
-- ==============================================================================

-- 1. Create the issues table if it does not already exist
CREATE TABLE IF NOT EXISTS public.issues (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    category TEXT NOT NULL CHECK (
        category IN ('Garbage', 'Pothole/Road', 'Water Leakage', 'Streetlight', 'Other')
    ),
    location TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Reported' CHECK (
        status IN ('Reported', 'Under Review', 'In Progress', 'Resolved')
    ),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Performance indexes for listing, ordering, and duplicate detection
CREATE INDEX IF NOT EXISTS idx_issues_created_at ON public.issues(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_issues_category ON public.issues(category);
CREATE INDEX IF NOT EXISTS idx_issues_user_id ON public.issues(user_id);

-- 3. Enable Row Level Security (RLS)
ALTER TABLE public.issues ENABLE ROW LEVEL SECURITY;

-- 4. Set explicit role permissions (anon & authenticated can read and submit; no client updates/deletes)
GRANT USAGE ON SCHEMA public TO anon, authenticated;
GRANT SELECT, INSERT ON TABLE public.issues TO anon, authenticated;
REVOKE UPDATE, DELETE ON TABLE public.issues FROM anon, authenticated;

-- 5. Public read access policy (allows all citizens and visitors to view civic reports)
DROP POLICY IF EXISTS "Public read access" ON public.issues;
CREATE POLICY "Public read access"
ON public.issues FOR SELECT
TO anon, authenticated
USING (true);

-- 6. Authenticated user report submission policy
-- Enforces that logged-in users submit under their verified auth UID (or as guest/null) with initial status 'Reported'
DROP POLICY IF EXISTS "Authenticated secure insert" ON public.issues;
CREATE POLICY "Authenticated secure insert"
ON public.issues FOR INSERT
TO authenticated
WITH CHECK (
    (user_id = auth.uid() OR user_id IS NULL)
    AND status = 'Reported'
);

-- 7. Anonymous guest report submission policy
-- Allows unauthenticated visitors to report issues with user_id = NULL and initial status 'Reported'
DROP POLICY IF EXISTS "Guest anonymous insert" ON public.issues;
CREATE POLICY "Guest anonymous insert"
ON public.issues FOR INSERT
TO anon
WITH CHECK (
    user_id IS NULL
    AND status = 'Reported'
);

-- 8. Seeded Demo Reports Status Update
-- Updates the status of the historical demo reports to demonstrate varied resolution stages
UPDATE public.issues
SET status = CASE
    WHEN title = 'Large Pothole on Main Road' AND location = 'Gomti Nagar, Lucknow' THEN 'In Progress'
    WHEN title = 'Water Leakage from Pipeline' AND location = 'Indira Nagar, Lucknow' THEN 'Resolved'
    WHEN title = 'Damaged Footpath Near Market' AND location = 'Hazratganj, Lucknow' THEN 'In Progress'
    WHEN title = 'Blocked Drain Causing Waterlogging' AND location = 'Jankipuram, Lucknow' THEN 'Resolved'
    ELSE status
END
WHERE title IN (
    'Large Pothole on Main Road',
    'Water Leakage from Pipeline',
    'Damaged Footpath Near Market',
    'Blocked Drain Causing Waterlogging'
) AND location IN (
    'Gomti Nagar, Lucknow',
    'Indira Nagar, Lucknow',
    'Hazratganj, Lucknow',
    'Jankipuram, Lucknow'
);
