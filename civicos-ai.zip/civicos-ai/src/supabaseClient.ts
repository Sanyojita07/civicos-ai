import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Helper to sanitize environment values:
// 1. Trims whitespace
// 2. Removes wrapping quotes (' or ")
// 3. Strips accidental prepended variable names (e.g. "NEXT_PUBLIC_...=" or "VITE_...=")
const sanitizeEnvValue = (val?: string): string => {
  if (!val) return '';
  let str = val.trim();
  // Strip outer quotes
  if ((str.startsWith('"') && str.endsWith('"')) || (str.startsWith("'") && str.endsWith("'"))) {
    str = str.slice(1, -1).trim();
  }
  // Strip accidental key assignment prefix like "NEXT_PUBLIC_SUPABASE_URL="
  const keyAssignmentMatch = str.match(/^(?:[A-Z0-9_]+)\s*=\s*(.+)$/);
  if (keyAssignmentMatch) {
    str = keyAssignmentMatch[1].trim();
  }
  return str;
};

// Check primary variable names with common fallbacks
const rawUrl = sanitizeEnvValue(
  import.meta.env.VITE_SUPABASE_URL ||
  import.meta.env.NEXT_PUBLIC_SUPABASE_URL
);

const rawKey = sanitizeEnvValue(
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  import.meta.env.VITE_SUPABASE_ANON_KEY ||
  import.meta.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
  import.meta.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
);

// Validate whether a string is a well-formed HTTP/HTTPS URL
const isValidHttpUrl = (urlString?: string): boolean => {
  if (!urlString) return false;
  try {
    const url = new URL(urlString);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    return false;
  }
};

export const isSupabaseConfigured: boolean = Boolean(
  rawUrl &&
  rawKey &&
  rawUrl.length > 0 &&
  rawKey.length > 0 &&
  !rawUrl.includes('placeholder') &&
  !rawKey.includes('placeholder') &&
  !rawUrl.includes('your-supabase-url') &&
  !rawKey.includes('your-publishable-key') &&
  isValidHttpUrl(rawUrl)
);

let client: SupabaseClient | null = null;

if (isSupabaseConfigured && rawUrl && rawKey) {
  try {
    client = createClient(rawUrl, rawKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
      },
    });
  } catch (error) {
    console.warn('Failed to initialize Supabase client:', error);
    client = null;
  }
}

export const supabase: SupabaseClient | null = client;
