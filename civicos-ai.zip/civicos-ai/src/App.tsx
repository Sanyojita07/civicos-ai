import React, { useState, useEffect, useCallback } from 'react';
import { ViewType, Issue } from './types';
import { supabase, isSupabaseConfigured } from './supabaseClient';
import { DEMO_SAMPLE_REPORTS, seedHistoricalDemoReports } from './demoData';
import { Navbar } from './components/Navbar';
import { AuthModal } from './components/AuthModal';
import { OverviewView } from './views/OverviewView';
import { ReportIssueView } from './views/ReportIssueView';
import { ExploreReportsView } from './views/ExploreReportsView';
import { MyReportsView } from './views/MyReportsView';
import { TrackingReportsView } from './views/TrackingReportsView';
import { GuidelinesView } from './views/GuidelinesView';
import { AlertTriangle, Database, ShieldCheck, Heart } from 'lucide-react';

export const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<ViewType>('overview');
  const [issues, setIssues] = useState<Issue[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Auth state
  const [authModalOpen, setAuthModalOpen] = useState<boolean>(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [userEmail, setUserEmail] = useState<string | null>(null);

  // Guest IDs from localStorage
  const [guestIssueIds, setGuestIssueIds] = useState<string[]>([]);

  // Safely read guest issue IDs from localStorage
  const loadGuestIssueIds = useCallback(() => {
    try {
      const stored = localStorage.getItem('guest_issue_ids');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          setGuestIssueIds(parsed);
          return;
        }
      }
    } catch {
      // Ignore localStorage read errors
    }
    setGuestIssueIds([]);
  }, []);

  // Fetch reports
  const fetchIssues = useCallback(async () => {
    setLoading(true);
    setError(null);

    // DEMO MODE: If Supabase client is null or not configured
    if (!isSupabaseConfigured || !supabase) {
      setIssues(DEMO_SAMPLE_REPORTS);
      setLoading(false);
      return;
    }

    // LIVE MODE: Query real Supabase database
    try {
      const { data, error: fetchError } = await supabase
        .from('issues')
        .select('*')
        .order('created_at', { ascending: false });

      if (fetchError) {
        setError(fetchError.message);
        setIssues([]);
      } else if (data && data.length === 0) {
        // Automatically seed historical demo reports if the database table is empty
        await seedHistoricalDemoReports(supabase);
        const { data: refetched } = await supabase
          .from('issues')
          .select('*')
          .order('created_at', { ascending: false });
        setIssues(refetched || []);
      } else {
        setIssues(data || []);
      }
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Failed to query database.';
      setError(message);
      setIssues([]);
    } finally {
      setLoading(false);
    }
  }, []);

  // Check auth session
  useEffect(() => {
    loadGuestIssueIds();

    if (!isSupabaseConfigured || !supabase) {
      fetchIssues();
      return;
    }

    // Live auth check
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        setUserId(session.user.id);
        setUserEmail(session.user.email ?? null);
      } else {
        setUserId(null);
        setUserEmail(null);
      }
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      if (session?.user) {
        setUserId(session.user.id);
        setUserEmail(session.user.email ?? null);
      } else {
        setUserId(null);
        setUserEmail(null);
      }
    });

    fetchIssues();

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchIssues, loadGuestIssueIds]);

  const handleSignOut = async () => {
    if (supabase) {
      await supabase.auth.signOut();
      setUserId(null);
      setUserEmail(null);
    }
  };

  const handleAuthSuccess = () => {
    if (supabase) {
      supabase.auth.getSession().then(({ data: { session } }) => {
        if (session?.user) {
          setUserId(session.user.id);
          setUserEmail(session.user.email ?? null);
        }
      });
    }
  };

  const handleIssueCreated = (newIssueId: string) => {
    loadGuestIssueIds();
    fetchIssues();
    if (!guestIssueIds.includes(newIssueId)) {
      setGuestIssueIds((prev) => [...prev, newIssueId]);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC]">
      
      {/* Exact Demo Mode Banner Requirement */}
      {!isSupabaseConfigured && (
        <div className="bg-amber-500 text-slate-950 font-bold px-4 py-2.5 text-center text-xs sm:text-sm flex items-center justify-center gap-2 shadow-sm border-b border-amber-600">
          <AlertTriangle className="w-4 h-4 flex-shrink-0 text-slate-950" />
          <span>
            Running in Demo Mode. Configure Supabase environment variables to enable real database operations.
          </span>
        </div>
      )}

      {/* Navigation */}
      <Navbar
        currentView={currentView}
        onNavigate={setCurrentView}
        userEmail={userEmail}
        onOpenAuth={() => setAuthModalOpen(true)}
        onSignOut={handleSignOut}
        isDemo={!isSupabaseConfigured}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        {currentView === 'overview' && (
          <OverviewView
            issues={issues}
            loading={loading}
            error={error}
            onNavigate={setCurrentView}
            isDemo={!isSupabaseConfigured}
          />
        )}

        {currentView === 'report' && (
          <ReportIssueView
            userId={userId}
            isDemo={!isSupabaseConfigured}
            onIssueCreated={handleIssueCreated}
            onNavigate={setCurrentView}
            existingIssues={issues}
          />
        )}

        {currentView === 'tracking' && (
          <TrackingReportsView
            issues={issues}
            loading={loading}
            error={error}
            isDemo={!isSupabaseConfigured}
            onNavigate={setCurrentView}
          />
        )}

        {currentView === 'explore' && (
          <ExploreReportsView
            issues={issues}
            loading={loading}
            error={error}
            isDemo={!isSupabaseConfigured}
          />
        )}

        {currentView === 'my-reports' && (
          <MyReportsView
            issues={issues}
            loading={loading}
            error={error}
            userId={userId}
            userEmail={userEmail}
            guestIssueIds={guestIssueIds}
            isDemo={!isSupabaseConfigured}
            onOpenAuth={() => setAuthModalOpen(true)}
            onNavigate={setCurrentView}
          />
        )}

        {currentView === 'guidelines' && (
          <GuidelinesView
            onNavigate={setCurrentView}
            isDemo={!isSupabaseConfigured}
          />
        )}
      </main>

      {/* Enhanced Footer */}
      <footer className="bg-[#0F172A] border-t border-slate-800 text-slate-400 py-10 text-xs mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          
          {/* Contact Us Section */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-[0_10px_30px_rgba(15,23,42,0.2)]">
            <div className="max-w-xl space-y-2">
              <h3 className="text-lg sm:text-xl font-black text-white tracking-tight">Contact Us</h3>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                Questions about reporting a civic issue? Explore our resources to learn how to submit useful, accurate reports.
              </p>
              <p className="text-xs text-slate-400 pt-1 font-medium">
                Official contact details coming soon.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={() => setCurrentView('guidelines')}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-teal/15 hover:bg-teal/25 text-[#A3E635] text-xs font-bold border border-teal/40 transition active:scale-95 shadow-sm"
              >
                <span>Community &amp; Guidelines &rarr;</span>
              </button>
              <button
                onClick={() => setCurrentView('explore')}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-semibold border border-slate-700 transition active:scale-95 shadow-sm"
              >
                <span>Explore Reports &rarr;</span>
              </button>
            </div>
          </div>

          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            
            {/* Branding & Hackathon note */}
            <div className="flex flex-col sm:flex-row items-center gap-2.5 sm:gap-3 text-center sm:text-left">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-md bg-teal flex items-center justify-center font-bold text-white text-xs">
                  C
                </div>
                <span className="font-extrabold text-white tracking-wide text-sm">CivicOS AI</span>
              </div>
              <span className="hidden sm:inline text-slate-600">&bull;</span>
              <span className="text-slate-400 font-medium">Civic-Tech Hackathon MVP</span>
              <span className="hidden sm:inline text-slate-600">&bull;</span>
              <span className="inline-flex items-center gap-1 text-slate-400">
                <ShieldCheck className="w-3.5 h-3.5 text-[#A3E635]" /> Public Civic Accountability
              </span>
            </div>

            {/* Mode & License */}
            <div className="flex items-center gap-3">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900 border border-slate-700/80 text-xs">
                <Database className="w-3.5 h-3.5 text-teal" />
                Mode: <strong className="text-slate-200">{isSupabaseConfigured ? 'Live Supabase' : 'Demo Mode'}</strong>
              </span>
              <span className="text-slate-600">&bull;</span>
              <span className="text-slate-400">MIT Open Source</span>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-2 text-slate-500 text-[11px]">
            <p>Empowering local communities and municipal responders through transparent civic reporting.</p>
            <p className="flex items-center gap-1">
              Built with <Heart className="w-3 h-3 text-rose-500 fill-rose-500" /> for civic improvement
            </p>
          </div>
        </div>
      </footer>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onAuthSuccess={handleAuthSuccess}
      />
    </div>
  );
};
