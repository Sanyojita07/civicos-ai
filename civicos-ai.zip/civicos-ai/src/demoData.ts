import { Issue } from './types';
import { SupabaseClient } from '@supabase/supabase-js';

export const HISTORICAL_DEMO_REPORTS: Omit<Issue, 'id'>[] = [
  {
    user_id: null,
    title: 'Garbage Overflow Near Residential Area',
    description: 'Demo report: Waste has accumulated near residential dustbins, causing foul smells.',
    category: 'Garbage',
    location: 'Aliganj, Lucknow',
    status: 'Reported',
    created_at: '2026-10-05T09:30:00+05:30',
  },
  {
    user_id: null,
    title: 'Large Pothole on Main Road',
    description: 'Demo report: A large pothole makes road travel difficult, especially after rain.',
    category: 'Pothole/Road',
    location: 'Gomti Nagar, Lucknow',
    status: 'In Progress',
    created_at: '2026-09-21T11:15:00+05:30',
  },
  {
    user_id: null,
    title: 'Water Leakage from Pipeline',
    description: 'Demo report: A roadside pipeline leak is causing waterlogging and water wastage.',
    category: 'Water Leakage',
    location: 'Indira Nagar, Lucknow',
    status: 'Resolved',
    created_at: '2026-09-08T14:00:00+05:30',
  },
  {
    user_id: null,
    title: 'Non-Functional Streetlight',
    description: 'Demo report: A streetlight near a residential crossing is not working.',
    category: 'Streetlight',
    location: 'Mahanagar, Lucknow',
    status: 'Reported',
    created_at: '2026-08-17T19:45:00+05:30',
  },
  {
    user_id: null,
    title: 'Damaged Footpath Near Market',
    description: 'Demo report: Broken pavement is obstructing pedestrian movement.',
    category: 'Pothole/Road',
    location: 'Hazratganj, Lucknow',
    status: 'In Progress',
    created_at: '2026-07-29T10:20:00+05:30',
  },
  {
    user_id: null,
    title: 'Blocked Drain Causing Waterlogging',
    description: 'Demo report: A blocked drain is causing stagnant water to collect near the street.',
    category: 'Other',
    location: 'Jankipuram, Lucknow',
    status: 'Resolved',
    created_at: '2026-06-12T08:00:00+05:30',
  },
];

export const DEMO_SAMPLE_REPORTS: Issue[] = HISTORICAL_DEMO_REPORTS.map((report, idx) => ({
  ...report,
  id: `demo-${idx + 1}`,
}));

/**
 * Idempotently seed historical demo reports into the live Supabase database
 * if they are not already present.
 */
export async function seedHistoricalDemoReports(client: SupabaseClient): Promise<void> {
  try {
    for (const report of HISTORICAL_DEMO_REPORTS) {
      const { data: existing, error: checkError } = await client
        .from('issues')
        .select('id')
        .eq('title', report.title)
        .limit(1);

      if (checkError) {
        console.warn('Could not check demo report existence:', checkError.message);
        continue;
      }

      if (!existing || existing.length === 0) {
        const { error: insertError } = await client
          .from('issues')
          .insert(report);

        if (insertError) {
          console.warn('Failed to insert demo report:', report.title, insertError.message);
        }
      }
    }
  } catch (err) {
    console.warn('Unexpected error during demo report seeding:', err);
  }
}
