import React, { useState, useMemo } from 'react';
import { Issue, IssueCategory, IssueStatus, ViewType } from '../types';
import { StatusBadge } from '../components/StatusBadge';
import { ReportProgressTimeline } from '../components/ReportProgressTimeline';
import {
  Search,
  RotateCcw,
  Hash,
  MapPin,
  Calendar,
  AlertCircle,
  FileQuestion,
  ChevronRight,
  Layers,
} from 'lucide-react';

interface Props {
  issues: Issue[];
  loading: boolean;
  error: string | null;
  isDemo: boolean;
  onNavigate: (view: ViewType) => void;
}

const CATEGORIES: IssueCategory[] = [
  'Garbage',
  'Pothole/Road',
  'Water Leakage',
  'Streetlight',
  'Other',
];

const STATUSES: IssueStatus[] = ['Reported', 'Under Review', 'In Progress', 'Resolved'];

export const TrackingReportsView: React.FC<Props> = ({
  issues,
  loading,
  error,
  isDemo,
  onNavigate,
}) => {
  // Search & Filters state
  const [searchIdQuery, setSearchIdQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');

  // Currently selected report for detail view & progress timeline inspection
  const [selectedReportId, setSelectedReportId] = useState<string | null>(null);

  // Filtered issues calculation
  const filteredIssues = useMemo(() => {
    return issues.filter((issue) => {
      // 1. Report ID or keyword search
      const q = searchIdQuery.trim().toLowerCase();
      const matchesSearch =
        q === '' ||
        issue.id.toLowerCase().includes(q) ||
        issue.title.toLowerCase().includes(q) ||
        issue.location.toLowerCase().includes(q);

      // 2. Category filter
      const matchesCategory =
        selectedCategory === 'All' || issue.category === selectedCategory;

      // 3. Status filter
      const matchesStatus =
        selectedStatus === 'All' || issue.status === selectedStatus;

      return matchesSearch && matchesCategory && matchesStatus;
    });
  }, [issues, searchIdQuery, selectedCategory, selectedStatus]);

  // Selected report object
  const activeReport = useMemo(() => {
    if (!selectedReportId) return null;
    return issues.find((i) => i.id === selectedReportId) || null;
  }, [issues, selectedReportId]);

  const hasActiveFilters =
    searchIdQuery.trim() !== '' || selectedCategory !== 'All' || selectedStatus !== 'All';

  const handleResetFilters = () => {
    setSearchIdQuery('');
    setSelectedCategory('All');
    setSelectedStatus('All');
  };

  const formatDate = (dateString: string) => {
    try {
      const d = new Date(dateString);
      return d.toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return dateString;
    }
  };

  return (
    <div className="w-full space-y-8 motion-reveal">
      
      {/* Hero Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0F172A] via-[#111e38] to-[#0A0F1D] text-white p-7 sm:p-10 lg:p-12 shadow-[0_20px_50px_rgba(15,23,42,0.22)] border border-slate-800">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-teal/15 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-1/2 -right-24 w-96 h-96 bg-lime/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold bg-teal/20 text-[#A3E635] border border-teal/40 shadow-inner mb-4">
            <Hash className="w-4 h-4 text-[#A3E635]" />
            <span>REPORT TRACKING</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white mb-4 leading-tight">
            Track Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-teal-400 to-[#A3E635]">Civic Reports</span>
          </h1>

          <p className="text-xs sm:text-base text-slate-300 leading-relaxed max-w-2xl">
            Find reports by unique Report ID or keyword, view available status information and milestone timelines, and follow municipal resolution progress.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-6">
            <button
              onClick={() => onNavigate('report')}
              className="motion-button inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-teal to-teal-700 hover:from-teal-600 hover:to-teal-800 text-white text-xs sm:text-sm font-bold shadow-md transition-all active:scale-95"
            >
              <span>+ Report an Issue</span>
            </button>
            <button
              onClick={() => onNavigate('explore')}
              className="motion-button inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-semibold border border-slate-700 transition-all active:scale-95"
            >
              <Layers className="w-4 h-4 text-teal" />
              <span>Browse All Reports</span>
            </button>
          </div>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="motion-reveal motion-delay-1 w-full bg-white rounded-2xl border border-slate-200/90 shadow-[0_2px_10px_rgba(15,23,42,0.03)] p-4 sm:p-5 space-y-3 lg:space-y-0 lg:flex lg:items-center lg:gap-4">
        
        {/* Report ID or Search text */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={searchIdQuery}
            onChange={(e) => setSearchIdQuery(e.target.value)}
            aria-label="Search by Report ID, title, or location"
            placeholder="Search by Report ID, title, or location..."
            className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm border border-slate-200 rounded-xl bg-slate-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal/30 focus:border-teal transition"
          />
        </div>

        {/* Status and Category Filter Dropdowns */}
        <div className="flex flex-wrap sm:flex-nowrap items-center gap-3">
          {/* Status Filter */}
          <div className="flex-1 sm:flex-initial">
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              aria-label="Filter tracking reports by status"
              className="w-full sm:w-auto px-3.5 py-2.5 text-xs sm:text-sm border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-teal/30 focus:border-teal transition cursor-pointer"
            >
              <option value="All">All Statuses</option>
              {STATUSES.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>

          {/* Category Filter */}
          <div className="flex-1 sm:flex-initial">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              aria-label="Filter tracking reports by category"
              className="w-full sm:w-auto px-3.5 py-2.5 text-xs sm:text-sm border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-teal/30 focus:border-teal transition cursor-pointer"
            >
              <option value="All">All Categories</option>
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Reset Filters button */}
          {hasActiveFilters && (
            <button
              onClick={handleResetFilters}
              className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition active:scale-95"
              title="Reset Filters"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>

      {/* Active Detail Modal / Expanded Drawer (When a user clicks 'Track Details') */}
      {activeReport && (
        <div className="motion-reveal bg-white rounded-3xl border border-teal-200 shadow-[0_12px_40px_rgba(13,148,136,0.12)] p-6 sm:p-8 space-y-6">
          <div className="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <span className="font-mono text-xs font-bold text-teal bg-teal-50 px-2.5 py-1 rounded-lg border border-teal-200 flex items-center gap-1">
                  <Hash className="w-3 h-3" />
                  {activeReport.id}
                </span>
                <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-slate-100 text-slate-700">
                  {activeReport.category}
                </span>
                {isDemo && (
                  <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
                    Demo Record
                  </span>
                )}
              </div>
              <h2 className="text-xl sm:text-2xl font-black text-navy">{activeReport.title}</h2>
            </div>

            <div className="flex items-center gap-3">
              <StatusBadge status={activeReport.status} />
              <button
                onClick={() => setSelectedReportId(null)}
                className="motion-button px-3.5 py-1.5 rounded-xl text-xs font-bold text-slate-500 hover:text-navy hover:bg-slate-100 border border-slate-200 transition active:scale-95"
              >
                Close Inspector &times;
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left 2 Cols: Report Info */}
            <div className="lg:col-span-2 space-y-4">
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 mb-1">Description</h4>
                <p className="text-sm text-slate-700 leading-relaxed bg-slate-50/70 p-4 rounded-xl border border-slate-200/80 whitespace-pre-line">
                  {activeReport.description}
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div className="bg-slate-50/70 p-3.5 rounded-xl border border-slate-200/80">
                  <span className="text-slate-400 font-medium block text-[11px] uppercase">Registered Location</span>
                  <div className="flex items-center gap-1.5 font-bold text-slate-800 mt-1">
                    <MapPin className="w-4 h-4 text-teal flex-shrink-0" />
                    <span>{activeReport.location}</span>
                  </div>
                </div>

                <div className="bg-slate-50/70 p-3.5 rounded-xl border border-slate-200/80">
                  <span className="text-slate-400 font-medium block text-[11px] uppercase">Submission Timestamp</span>
                  <div className="flex items-center gap-1.5 font-bold text-slate-800 mt-1">
                    <Calendar className="w-4 h-4 text-teal flex-shrink-0" />
                    <span>{formatDate(activeReport.created_at)}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Col: Timeline strictly derived from schema without fake intermediate events */}
            <div className="lg:col-span-1">
              <ReportProgressTimeline status={activeReport.status} createdAt={activeReport.created_at} />
            </div>
          </div>
        </div>
      )}

      {/* Main List Section */}
      {loading ? (
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-16 text-center text-slate-500 text-xs font-medium">
          Loading report tracking records...
        </div>
      ) : error ? (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-6 text-xs text-rose-700 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-sm">Error Loading Reports</p>
            <p className="mt-1 text-rose-600">{error}</p>
          </div>
        </div>
      ) : filteredIssues.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200/90 p-16 text-center text-slate-500 shadow-sm">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center mx-auto mb-3 text-slate-400">
            <FileQuestion className="w-6 h-6" />
          </div>
          <p className="font-bold text-navy text-base">No matching reports found</p>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            No issues match the entered Report ID or selected filters. Clear your search to view all logged municipal cases.
          </p>
          {hasActiveFilters && (
            <button
              onClick={handleResetFilters}
              className="mt-4 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-xs font-bold rounded-xl text-slate-700 transition active:scale-95 shadow-sm border border-slate-200/80"
            >
              Reset Search & Filters
            </button>
          )}
        </div>
      ) : (
        <div className="motion-reveal motion-delay-2 space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-500 px-1 py-1">
            <div className="flex items-center gap-1.5 font-medium">
              <Layers className="w-3.5 h-3.5 text-teal" />
              <span>
                Found <strong className="text-navy">{filteredIssues.length}</strong> {filteredIssues.length === 1 ? 'report' : 'reports'}
              </span>
            </div>
            {hasActiveFilters && (
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-teal-50 text-teal border border-teal-200">
                Active search filters
              </span>
            )}
          </div>

          {/* Report Tracking Table / Card Grid */}
          <div className="space-y-3">
            {filteredIssues.map((report) => {
              const isSelected = selectedReportId === report.id;

              return (
                <div
                  key={report.id}
                  className={`motion-card bg-white rounded-2xl border p-5 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-sm ${
                    isSelected ? 'border-teal ring-2 ring-teal/20' : 'border-slate-200/90'
                  }`}
                >
                  {/* Left Column: ID & Basic Details */}
                  <div className="space-y-1.5 max-w-2xl">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-xs font-bold text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded-md flex items-center gap-1">
                        <Hash className="w-3 h-3 text-teal" />
                        <span className="truncate max-w-[200px]" title={report.id}>{report.id}</span>
                      </span>
                      <span className="text-xs font-medium text-slate-600 px-2 py-0.5 rounded bg-slate-100">
                        {report.category}
                      </span>
                      {isDemo && (
                        <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-50 px-2 py-0.5 rounded border border-slate-200">
                          Demo Sample
                        </span>
                      )}
                    </div>

                    <h3 className="text-base font-bold text-navy hover:text-teal transition-colors">
                      {report.title}
                    </h3>

                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                      {report.description}
                    </p>

                    <div className="flex flex-wrap items-center gap-3 pt-1 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-teal flex-shrink-0" />
                        <span className="truncate max-w-[250px]">{report.location}</span>
                      </span>
                      <span>&bull;</span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
                        <span>Submitted {formatDate(report.created_at)}</span>
                      </span>
                    </div>
                  </div>

                  {/* Right Column: Status & Action Button */}
                  <div className="flex items-center justify-between md:justify-end gap-3 pt-3 md:pt-0 border-t md:border-t-0 border-slate-100">
                    <StatusBadge status={report.status} />

                    <button
                      onClick={() => setSelectedReportId(isSelected ? null : report.id)}
                      className={`motion-button inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all active:scale-95 ${
                        isSelected
                          ? 'bg-navy text-white shadow-sm ring-2 ring-navy/20'
                          : 'bg-teal-50 hover:bg-teal hover:text-white text-teal border border-teal-200/80'
                      }`}
                    >
                      <span>{isSelected ? 'Hide Timeline' : 'Track Status'}</span>
                      <ChevronRight className={`w-3.5 h-3.5 transition-transform duration-200 ${isSelected ? 'rotate-90' : ''}`} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

    </div>
  );
};
