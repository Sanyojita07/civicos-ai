import React, { useMemo } from 'react';
import { Issue, ViewType } from '../types';
import { IssueCard } from '../components/IssueCard';
import {
  FolderCheck,
  UserCheck,
  Globe,
  PlusCircle,
  LogIn,
  AlertCircle,
  Info,
  Clock,
} from 'lucide-react';

interface Props {
  issues: Issue[];
  loading: boolean;
  error: string | null;
  userId: string | null;
  userEmail: string | null;
  guestIssueIds: string[];
  isDemo: boolean;
  onOpenAuth: () => void;
  onNavigate: (view: ViewType) => void;
}

export const MyReportsView: React.FC<Props> = ({
  issues,
  loading,
  error,
  userId,
  userEmail,
  guestIssueIds,
  isDemo,
  onOpenAuth,
  onNavigate,
}) => {
  const myIssues = useMemo(() => {
    if (isDemo) {
      return issues.slice(0, 2);
    }
    if (userId) {
      return issues.filter((i) => i.user_id === userId);
    } else {
      return issues.filter((i) => guestIssueIds.includes(i.id));
    }
  }, [issues, userId, guestIssueIds, isDemo]);

  return (
    <div className="w-full space-y-6 motion-reveal">
      
      {/* Hero Header Banner */}
      <div className="motion-reveal relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0F172A] via-[#111e38] to-[#0A0F1D] text-white p-7 sm:p-10 lg:p-12 shadow-[0_20px_50px_rgba(15,23,42,0.22)] border border-slate-800">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-teal/15 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-1/2 -right-24 w-96 h-96 bg-lime/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold bg-teal/20 text-[#A3E635] border border-teal/40 shadow-inner mb-4">
            <UserCheck className="w-4 h-4 text-[#A3E635]" />
            <span>YOUR CIVIC ACTIVITY</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white mb-4 leading-tight">
            Your Reports, <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-teal-400 to-[#A3E635]">All in One Place</span>
          </h1>

          <p className="text-xs sm:text-base text-slate-300 leading-relaxed max-w-2xl">
            Review your submitted civic issues, monitor their available saved statuses, and follow resolution milestones with ease.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-6">
            <button
              onClick={() => onNavigate('tracking')}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-teal to-teal-700 hover:from-teal-600 hover:to-teal-800 text-white text-xs sm:text-sm font-bold shadow-md transition-all active:scale-95"
            >
              <span>Live Tracking Desk &rarr;</span>
            </button>
            {!userId && !isDemo && (
              <button
                onClick={onOpenAuth}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-semibold border border-slate-700 transition-all active:scale-95"
              >
                <LogIn className="w-4 h-4 text-teal" />
                <span>Sign In to Sync</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Account / Guest Mode Status Banner */}
      {userId ? (
        <div className="w-full bg-white rounded-2xl border border-slate-200/90 p-5 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-700 shadow-[0_2px_10px_rgba(15,23,42,0.03)]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-200 flex items-center justify-center text-teal">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="font-bold text-navy text-sm">Authenticated Citizen Profile</p>
              <p className="text-slate-500 mt-0.5">
                Displaying issues tied to your verified account (<strong>{userEmail}</strong>).
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold text-xs flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            Cloud Synced
          </span>
        </div>
      ) : isDemo ? (
        <div className="w-full bg-teal-50/90 border border-teal-200 rounded-2xl p-5 flex items-start gap-3.5 text-xs text-teal-900 leading-relaxed shadow-sm">
          <Info className="w-5 h-5 text-teal flex-shrink-0 mt-0.5" />
          <div>
            <strong className="font-bold text-teal-950 block mb-0.5">Demo Mode Preview:</strong>
            Displaying sample submitted reports for demonstration. In live mode, guest reports will be tracked via your browser's local storage or tied to your authenticated Supabase profile.
          </div>
        </div>
      ) : (
        <div className="w-full bg-amber-50/90 border border-amber-200 rounded-2xl p-5 flex items-start gap-3.5 text-xs text-amber-900 leading-relaxed shadow-sm">
          <div className="w-9 h-9 rounded-xl bg-amber-100 border border-amber-200 flex items-center justify-center text-amber-700 flex-shrink-0 mt-0.5">
            <Globe className="w-4 h-4" />
          </div>
          <div>
            <strong className="font-bold block text-amber-950 mb-0.5">Guest Reporting Mode (Browser Session):</strong>
            You are browsing as a guest. Your submitted reports are identified using IDs stored in your local browser storage (<code className="px-1.5 py-0.5 bg-amber-100 rounded text-amber-950 font-mono text-xs">guest_issue_ids</code>). Guest history is specific to this browser and may disappear if your browser cookies or cache are cleared. To keep a permanent history across devices, consider signing up for a CivicOS account.
          </div>
        </div>
      )}

      {/* Reports Listing */}
      {loading ? (
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-16 text-center text-slate-500 text-xs font-medium">
          Loading your submitted reports...
        </div>
      ) : error ? (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-6 text-xs text-rose-700 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-sm">Unable to load your reports</p>
            <p className="mt-1 text-rose-600">{error}</p>
          </div>
        </div>
      ) : myIssues.length === 0 ? (
        <div className="w-full bg-white rounded-3xl border border-slate-200/90 p-16 text-center text-slate-500 shadow-sm">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center mx-auto mb-3 text-slate-400">
            <FolderCheck className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-navy text-base">No submitted reports found</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto leading-relaxed">
            {userId
              ? "You haven't submitted any civic issues with this account yet."
              : "No guest reports were found in this browser's local storage. Any reports submitted in this session will appear here."}
          </p>
          <button
            onClick={() => onNavigate('report')}
            className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal to-teal-700 hover:from-teal-600 hover:to-teal-800 text-white rounded-xl text-xs font-bold shadow-sm hover:shadow-md active:scale-95 transition-all"
          >
            <PlusCircle className="w-4 h-4 text-[#A3E635]" />
            <span>Submit a Report</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4 w-full motion-reveal motion-delay-2">
          <div className="flex items-center justify-between text-xs text-slate-500 px-1 py-1">
            <div className="flex items-center gap-1.5 font-medium">
              <Clock className="w-3.5 h-3.5 text-teal" />
              <span>
                Found <strong className="text-navy">{myIssues.length}</strong> {myIssues.length === 1 ? 'report' : 'reports'} submitted by you
              </span>
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6 w-full">
            {myIssues.map((issue) => (
              <IssueCard key={issue.id} issue={issue} isDemo={isDemo} />
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
