import React, { useState, useMemo } from 'react';
import { Issue, IssueCategory, IssueStatus } from '../types';
import { IssueCard } from '../components/IssueCard';
import { Search, RotateCcw, Filter, AlertCircle, FileQuestion, Layers } from 'lucide-react';

interface Props {
  issues: Issue[];
  loading: boolean;
  error: string | null;
  isDemo: boolean;
}

const CATEGORIES: IssueCategory[] = [
  'Garbage',
  'Pothole/Road',
  'Water Leakage',
  'Streetlight',
  'Other',
];

const STATUSES: IssueStatus[] = ['Reported', 'In Progress', 'Resolved'];

export const ExploreReportsView: React.FC<Props> = ({
  issues,
  loading,
  error,
  isDemo,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>(() => {
    try {
      return sessionStorage.getItem('civicos_filter_category') || 'All';
    } catch {
      return 'All';
    }
  });
  const [selectedStatus, setSelectedStatus] = useState<string>(() => {
    try {
      return sessionStorage.getItem('civicos_filter_status') || 'All';
    } catch {
      return 'All';
    }
  });

  const filteredIssues = useMemo(() => {
    return issues.filter((issue) => {
      const term = searchTerm.trim().toLowerCase();
      const matchesSearch =
        term === '' ||
        issue.title.toLowerCase().includes(term) ||
        issue.description.toLowerCase().includes(term) ||
        issue.location.toLowerCase().includes(term);

      const matchesCategory =
        selectedCategory === 'All' || issue.category === selectedCategory;

      const matchesStatus =
        selectedStatus === 'All' || issue.status === selectedStatus;

      return matchesSearch && matchesCategory && matchesStatus;
    });
  }, [issues, searchTerm, selectedCategory, selectedStatus]);

  const hasActiveFilters =
    searchTerm.trim() !== '' || selectedCategory !== 'All' || selectedStatus !== 'All';

  const handleResetFilters = () => {
    setSearchTerm('');
    setSelectedCategory('All');
    setSelectedStatus('All');
    try {
      sessionStorage.removeItem('civicos_filter_category');
      sessionStorage.removeItem('civicos_filter_status');
    } catch {
      // safe
    }
  };

  const handleCategoryChange = (val: string) => {
    setSelectedCategory(val);
    try {
      if (val === 'All') {
        sessionStorage.removeItem('civicos_filter_category');
      } else {
        sessionStorage.setItem('civicos_filter_category', val);
      }
    } catch {
      // safe
    }
  };

  const handleStatusChange = (val: string) => {
    setSelectedStatus(val);
    try {
      if (val === 'All') {
        sessionStorage.removeItem('civicos_filter_status');
      } else {
        sessionStorage.setItem('civicos_filter_status', val);
      }
    } catch {
      // safe
    }
  };

  return (
    <div className="w-full space-y-6 motion-reveal">
      
      {/* Hero Header Banner */}
      <div className="motion-reveal relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0F172A] via-[#111e38] to-[#0A0F1D] text-white p-7 sm:p-10 lg:p-12 shadow-[0_20px_50px_rgba(15,23,42,0.22)] border border-slate-800">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-teal/15 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-1/2 -right-24 w-96 h-96 bg-lime/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold bg-teal/20 text-[#A3E635] border border-teal/40 shadow-inner mb-4">
            <Layers className="w-4 h-4 text-[#A3E635]" />
            <span>PUBLIC CIVIC REPORTS</span>
          </div>

          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white mb-4 leading-tight">
            Explore <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-teal-400 to-[#A3E635]">Civic Reports</span>
          </h1>

          <p className="text-xs sm:text-base text-slate-300 leading-relaxed max-w-2xl">
            Search, filter, and explore available civic reports submitted by citizens across all municipal zones and sectors.
          </p>
        </div>
      </div>

      {/* Control Bar: Search & Filters */}
      <div className="motion-reveal motion-delay-1 w-full bg-white rounded-2xl border border-slate-200/90 shadow-[0_2px_10px_rgba(15,23,42,0.03)] p-4 sm:p-5 space-y-3 lg:space-y-0 lg:flex lg:items-center lg:gap-4">
        
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            aria-label="Search reports by title, keyword, description, or location"
            placeholder="Search reports by title, keyword, or description..."
            className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm border border-slate-200 rounded-xl bg-slate-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal/30 focus:border-teal transition"
          />
        </div>

        {/* Filters Group (stack on small mobile, row on tablet/desktop) */}
        <div className="flex flex-wrap sm:flex-nowrap items-center gap-3">
          {/* Category Filter */}
          <div className="flex items-center gap-2 flex-1 sm:flex-initial">
            <Filter className="w-4 h-4 text-slate-400 hidden sm:block" />
            <select
              value={selectedCategory}
              onChange={(e) => handleCategoryChange(e.target.value)}
              aria-label="Filter reports by category"
              className="w-full sm:w-auto px-3.5 py-2.5 text-xs sm:text-sm border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-teal/30 focus:border-teal transition cursor-pointer"
            >
              <option value="All">All Categories</option>
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex-1 sm:flex-initial">
            <select
              value={selectedStatus}
              onChange={(e) => handleStatusChange(e.target.value)}
              aria-label="Filter reports by status"
              className="w-full sm:w-auto px-3.5 py-2.5 text-xs sm:text-sm border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-teal/30 focus:border-teal transition cursor-pointer"
            >
              <option value="All">All Statuses</option>
              {STATUSES.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>

          {/* Reset Action */}
          {hasActiveFilters && (
            <button
              onClick={handleResetFilters}
              className="flex items-center justify-center gap-1.5 px-3.5 py-2.5 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 active:scale-95 rounded-xl border border-slate-200/80 transition shadow-sm"
              title="Reset Filters"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          )}
        </div>
      </div>

      {/* Main List / Grid */}
      {loading ? (
        <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-16 text-center text-slate-500 text-xs font-medium">
          Loading issues database...
        </div>
      ) : error ? (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-6 text-xs text-rose-700 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-bold text-sm">Error Loading Reports</p>
            <p className="mt-1 text-rose-600">{error}</p>
          </div>
        </div>
      ) : filteredIssues.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200/90 p-16 text-center text-slate-500 shadow-sm">
          <div className="w-14 h-14 rounded-2xl bg-slate-100 border border-slate-200 flex items-center justify-center mx-auto mb-3 text-slate-400">
            <FileQuestion className="w-6 h-6" />
          </div>
          <p className="font-bold text-navy text-base">No matching civic reports found</p>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Try adjusting your search query or reset active filters to inspect all logged community issues.
          </p>
          {hasActiveFilters && (
            <button
              onClick={handleResetFilters}
              className="mt-4 px-4 py-2 bg-slate-100 hover:bg-slate-200 text-xs font-bold rounded-xl text-slate-700 transition active:scale-95 shadow-sm"
            >
              Clear All Filters
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4 w-full motion-reveal motion-delay-2">
          <div className="flex items-center justify-between text-xs text-slate-500 px-1 py-1">
            <div className="flex items-center gap-1.5 font-medium">
              <Layers className="w-3.5 h-3.5 text-teal" />
              <span>
                Displaying <strong className="text-navy">{filteredIssues.length}</strong> of <strong className="text-navy">{issues.length}</strong> verified reports
              </span>
            </div>
            {hasActiveFilters && (
              <span className="text-xs font-semibold px-2.5 py-0.5 rounded-full bg-teal-50 text-teal border border-teal-200">
                Filters active
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6 w-full">
            {filteredIssues.map((issue) => (
              <IssueCard key={issue.id} issue={issue} isDemo={isDemo} />
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
