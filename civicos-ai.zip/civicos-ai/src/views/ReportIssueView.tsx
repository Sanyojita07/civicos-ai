import React, { useState } from 'react';
import { Issue, IssueCategory, ViewType } from '../types';
import { supabase } from '../supabaseClient';
import { DEMO_SAMPLE_REPORTS } from '../demoData';
import { StatusBadge } from '../components/StatusBadge';
import {
  Send,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Info,
  MapPin,
  FileText,
  Tag,
  ShieldAlert,
  PlusCircle,
  Hash,
  ArrowRight,
  Copy,
  Check,
} from 'lucide-react';

const CATEGORIES: IssueCategory[] = [
  'Garbage',
  'Pothole/Road',
  'Water Leakage',
  'Streetlight',
  'Other',
];

interface Props {
  userId: string | null;
  isDemo: boolean;
  onIssueCreated: (newIssueId: string) => void;
  onNavigate: (view: ViewType) => void;
  existingIssues?: Issue[];
}

export const ReportIssueView: React.FC<Props> = ({
  userId,
  isDemo,
  onIssueCreated,
  onNavigate,
  existingIssues = [],
}) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<IssueCategory>('Garbage');
  const [location, setLocation] = useState('');

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Submitted report confirmation state
  const [submittedReport, setSubmittedReport] = useState<{
    id: string;
    isDemo: boolean;
  } | null>(null);
  const [copied, setCopied] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  // Duplicate report alert state
  const [potentialDuplicates, setPotentialDuplicates] = useState<Issue[]>([]);
  const [showDuplicateAlert, setShowDuplicateAlert] = useState(false);

  // Copy Report ID to clipboard with safe fallback and explicit feedback
  const handleCopyReportId = async () => {
    if (!submittedReport?.id) return;
    const idToCopy = submittedReport.id;

    let succeeded = false;

    // 1. Try navigator.clipboard API
    if (navigator?.clipboard && typeof navigator.clipboard.writeText === 'function') {
      try {
        await navigator.clipboard.writeText(idToCopy);
        succeeded = true;
      } catch {
        succeeded = false;
      }
    }

    // 2. Safe fallback using temporary textarea
    if (!succeeded) {
      try {
        const textarea = document.createElement('textarea');
        textarea.value = idToCopy;
        textarea.style.position = 'fixed';
        textarea.style.top = '0';
        textarea.style.left = '0';
        textarea.style.opacity = '0';
        textarea.setAttribute('readonly', '');
        document.body.appendChild(textarea);
        textarea.select();
        succeeded = document.execCommand('copy');
        document.body.removeChild(textarea);
      } catch {
        succeeded = false;
      }
    }

    if (succeeded) {
      setCopied(true);
      setCopyFeedback('Report ID copied to clipboard!');
      setTimeout(() => {
        setCopied(false);
        setCopyFeedback(null);
      }, 3000);
    } else {
      setCopied(false);
      setCopyFeedback('Unable to copy automatically. Please copy the ID manually.');
      setTimeout(() => {
        setCopyFeedback(null);
      }, 4000);
    }
  };

  // Lightweight matching logic for detecting potentially similar reports
  const findSimilarReports = (
    cat: IssueCategory,
    loc: string,
    titleText: string,
    list: Issue[]
  ): Issue[] => {
    if (!list || list.length === 0) return [];

    const normLoc = (loc || '').toLowerCase().trim();
    const normTitle = (titleText || '').toLowerCase().trim();

    const stopWords = new Set([
      'the', 'and', 'near', 'at', 'in', 'of', 'on', 'by', 'next', 'to', 'opposite',
      'across', 'from', 'behind', 'front', 'around', 'outside', 'inside', 'corner',
      'street', 'st', 'road', 'rd', 'avenue', 'ave', 'lane', 'ln', 'drive', 'dr',
      'way', 'sector', 'block', 'area',
    ]);

    const getSignificantTokens = (text: string): string[] => {
      return text
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, ' ')
        .split(/\s+/)
        .filter((w) => w.length >= 3 && !stopWords.has(w));
    };

    const newLocTokens = getSignificantTokens(normLoc);
    const newTitleTokens = getSignificantTokens(normTitle);

    return list
      .filter((existing) => existing.category === cat)
      .map((existing) => {
        let score = 0;
        const exLoc = (existing.location || '').toLowerCase().trim();
        const exTitle = (existing.title || '').toLowerCase().trim();

        // Location comparison
        if (normLoc && exLoc && normLoc === exLoc) {
          score += 60;
        } else if (normLoc && exLoc && (normLoc.includes(exLoc) || exLoc.includes(normLoc))) {
          score += 40;
        } else if (normLoc && exLoc) {
          const exLocTokens = getSignificantTokens(exLoc);
          const matchingLocTokens = newLocTokens.filter((token) => exLocTokens.includes(token));
          score += matchingLocTokens.length * 20;
        }

        // Title token overlap
        if (score > 0 && normTitle && exTitle) {
          const exTitleTokens = getSignificantTokens(exTitle);
          const matchingTitleTokens = newTitleTokens.filter((token) => exTitleTokens.includes(token));
          score += matchingTitleTokens.length * 10;
        }

        return { existing, score };
      })
      .filter((item) => item.score >= 20)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3)
      .map((item) => item.existing);
  };

  // Check for duplicate candidates in Demo Mode or Supabase Mode
  const checkForDuplicates = async (
    reportCat: IssueCategory,
    reportLoc: string,
    reportTitle: string
  ): Promise<Issue[]> => {
    let candidates: Issue[] = existingIssues && existingIssues.length > 0 ? existingIssues : [];

    if (isDemo || !supabase) {
      if (candidates.length === 0) {
        candidates = DEMO_SAMPLE_REPORTS;
      }
    } else {
      try {
        const { data, error } = await supabase
          .from('issues')
          .select('*')
          .eq('category', reportCat)
          .limit(25);
        if (!error && data && data.length > 0) {
          candidates = data;
        }
      } catch {
        // Fall back gracefully to existing loaded candidates
      }
    }

    return findSimilarReports(reportCat, reportLoc, reportTitle, candidates);
  };

  // Submission executor (commits report to Demo Mode or Supabase)
  const executeSubmission = async (
    cleanTitle: string,
    cleanDescription: string,
    cleanLocation: string
  ) => {
    setLoading(true);

    if (isDemo || !supabase) {
      setTimeout(() => {
        setLoading(false);
        const demoId = `demo-${Date.now().toString(36)}`;

        try {
          const stored = localStorage.getItem('guest_issue_ids');
          const ids: string[] = stored ? JSON.parse(stored) : [];
          if (Array.isArray(ids)) {
            if (!ids.includes(demoId)) {
              ids.push(demoId);
              localStorage.setItem('guest_issue_ids', JSON.stringify(ids));
            }
          } else {
            localStorage.setItem('guest_issue_ids', JSON.stringify([demoId]));
          }
        } catch {
          // localStorage error handling
        }

        setSubmittedReport({
          id: demoId,
          isDemo: true,
        });
        setSuccessMsg(
          'Your report was verified and logged in Demo Mode. Real database persistence requires configuring Supabase environment variables.'
        );

        setTitle('');
        setDescription('');
        setLocation('');
        setCategory('Garbage');

        onIssueCreated(demoId);
      }, 600);
      return;
    }

    try {
      const payload = {
        title: cleanTitle,
        description: cleanDescription,
        category: category,
        location: cleanLocation,
        status: 'Reported' as const,
        user_id: userId || null,
      };

      const { data, error } = await supabase
        .from('issues')
        .insert(payload)
        .select()
        .single();

      if (error) {
        setErrorMsg(`Failed to submit report: ${error.message}`);
        setSubmittedReport(null);
        return;
      }

      if (!data || !data.id) {
        setErrorMsg('Report was submitted but no record was returned by the database.');
        setSubmittedReport(null);
        return;
      }

      if (!userId) {
        try {
          const stored = localStorage.getItem('guest_issue_ids');
          const ids: string[] = stored ? JSON.parse(stored) : [];
          if (Array.isArray(ids)) {
            if (!ids.includes(data.id)) {
              ids.push(data.id);
              localStorage.setItem('guest_issue_ids', JSON.stringify(ids));
            }
          } else {
            localStorage.setItem('guest_issue_ids', JSON.stringify([data.id]));
          }
        } catch {
          // localStorage error handling
        }
      }

      setSubmittedReport({
        id: data.id,
        isDemo: false,
      });
      setSuccessMsg('Your report has been successfully submitted and permanently saved to the municipal registry.');
      setTitle('');
      setDescription('');
      setLocation('');
      setCategory('Garbage');

      onIssueCreated(data.id);
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'An unexpected error occurred while submitting.';
      setErrorMsg(message);
      setSubmittedReport(null);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);
    setSubmittedReport(null);
    setCopied(false);
    setCopyFeedback(null);

    const cleanTitle = title.trim();
    const cleanDescription = description.trim();
    const cleanLocation = location.trim();

    if (!cleanTitle || !cleanDescription || !cleanLocation || !category) {
      setErrorMsg('Please fill out all required fields.');
      return;
    }

    if (!CATEGORIES.includes(category)) {
      setErrorMsg('Please select a valid category from the list.');
      return;
    }

    // Check for potential duplicate reports before submission
    setLoading(true);
    try {
      const duplicates = await checkForDuplicates(category, cleanLocation, cleanTitle);
      if (duplicates.length > 0) {
        setLoading(false);
        setPotentialDuplicates(duplicates);
        setShowDuplicateAlert(true);
        return;
      }
    } catch {
      // If check fails, do not block the user
    }

    // No duplicates detected -> proceed with standard submission
    await executeSubmission(cleanTitle, cleanDescription, cleanLocation);
  };

  const handleConfirmSubmitAnyway = async () => {
    setShowDuplicateAlert(false);
    setPotentialDuplicates([]);
    await executeSubmission(title.trim(), description.trim(), location.trim());
  };

  const handleCancelAlert = () => {
    setShowDuplicateAlert(false);
    setPotentialDuplicates([]);
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'Recent';
    try {
      const d = new Date(dateString);
      return d.toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return dateString;
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6 motion-reveal">
      
      {/* Hero Banner (Compact for immediate action) */}
      <div className="motion-reveal relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0F172A] via-[#111e38] to-[#0A0F1D] text-white p-6 sm:p-8 shadow-[0_16px_40px_rgba(15,23,42,0.18)] border border-slate-800">
        <div className="absolute -top-20 -left-20 w-72 h-72 bg-teal/15 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-1/2 -right-20 w-72 h-72 bg-lime/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-teal/20 text-[#A3E635] border border-teal/40 shadow-inner mb-3">
            <PlusCircle className="w-3.5 h-3.5 text-[#A3E635]" />
            <span>CITIZEN REPORTING</span>
          </div>

          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight text-white mb-2 leading-tight">
            Make Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-teal-400 to-[#A3E635]">Voice Heard</span>
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-xl">
            Report local civic hazards, damaged infrastructure, or sanitation concerns with clear descriptions and accurate locations to help municipal teams act swiftly.
          </p>
        </div>
      </div>

      {/* Privacy Notice Banner */}
      <div className="bg-amber-50/90 border border-amber-200/90 rounded-2xl p-4 sm:p-5 flex items-start gap-3.5 text-xs text-amber-900 leading-relaxed shadow-sm">
        <div className="w-9 h-9 rounded-xl bg-amber-100 border border-amber-300 flex items-center justify-center text-amber-700 flex-shrink-0 mt-0.5 shadow-sm">
          <ShieldAlert className="w-4 h-4" />
        </div>
        <div>
          <strong className="font-bold text-amber-950 block mb-1">Public Record & Privacy Warning</strong>
          Please do NOT include private phone numbers, home door numbers, passwords, or personally identifiable details. All submitted issues and their exact landmarks are indexed publicly for municipal transparency.
        </div>
      </div>

      {isDemo && (
        <div className="bg-teal-50/90 border border-teal-200/90 rounded-2xl p-4 sm:p-5 flex items-start gap-3.5 text-xs text-teal-900 leading-relaxed shadow-sm">
          <div className="w-9 h-9 rounded-xl bg-teal-100 border border-teal-300 flex items-center justify-center text-teal flex-shrink-0 mt-0.5 shadow-sm">
            <Info className="w-4 h-4 text-teal" />
          </div>
          <div>
            <strong className="font-bold block mb-0.5">Demo Mode Active:</strong>
            You can test the form inputs and validation, but persistent database operations require configuring Supabase environment variables.
          </div>
        </div>
      )}

      {/* Form Card */}
      <div className="motion-reveal motion-delay-2 w-full bg-white rounded-3xl border border-slate-200/90 shadow-[0_10px_30px_rgba(15,23,42,0.04)] p-6 sm:p-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          
          {errorMsg && (
            <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {submittedReport && (
            <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-br from-emerald-50/90 via-teal-50/40 to-slate-50 border border-emerald-200/90 text-emerald-950 space-y-4 shadow-sm motion-reveal">
              <div className="flex items-start gap-3.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-100 border border-emerald-300 flex items-center justify-center text-emerald-700 flex-shrink-0 mt-0.5 shadow-sm">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 border border-emerald-300">
                      Submission Confirmed
                    </span>
                    {submittedReport.isDemo && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-amber-100 text-amber-800 border border-amber-300">
                        Demo Mode
                      </span>
                    )}
                  </div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900 tracking-tight">
                    Report Submitted Successfully
                  </h3>
                  {successMsg && (
                    <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
                      {successMsg}
                    </p>
                  )}
                </div>
              </div>

              {/* Prominent Report ID Banner & Copy Report ID Button */}
              <div className="bg-white rounded-xl border border-emerald-200/90 p-3.5 sm:p-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 shadow-xs">
                <div className="min-w-0 space-y-1">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block">
                    Assigned Report ID
                  </span>
                  <div className="flex items-center gap-2">
                    <Hash className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                    <code className="font-mono text-xs sm:text-sm md:text-base font-bold text-slate-900 break-all select-all">
                      {submittedReport.id}
                    </code>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-shrink-0">
                  <button
                    type="button"
                    onClick={handleCopyReportId}
                    className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-2 shadow-xs active:scale-95 ${
                      copied
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-900 hover:bg-slate-800 text-white'
                    }`}
                    title="Copy Report ID to clipboard"
                  >
                    {copied ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-white stroke-[2.5]" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-slate-200" />
                        <span>Copy Report ID</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Explicit feedback when copying succeeds or fails */}
              {copyFeedback && (
                <div
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-2 transition ${
                    copied
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                      : 'bg-rose-50 text-rose-700 border border-rose-200'
                  }`}
                >
                  {copied ? (
                    <CheckCircle2 className="w-3.5 h-3.5 flex-shrink-0 text-emerald-600" />
                  ) : (
                    <AlertCircle className="w-3.5 h-3.5 flex-shrink-0 text-rose-600" />
                  )}
                  <span>{copyFeedback}</span>
                </div>
              )}

              {/* Navigation Actions */}
              <div className="pt-1 flex flex-wrap items-center gap-3 text-xs">
                <button
                  type="button"
                  onClick={() => onNavigate('my-reports')}
                  className="inline-flex items-center gap-1 font-bold text-teal hover:underline"
                >
                  <span>Track in My Reports</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
                <span className="text-slate-300">•</span>
                <button
                  type="button"
                  onClick={() => onNavigate('tracking')}
                  className="inline-flex items-center gap-1 font-semibold text-slate-600 hover:text-slate-900 hover:underline"
                >
                  <span>Open Tracking Desk</span>
                </button>
                <span className="text-slate-300">•</span>
                <button
                  type="button"
                  onClick={() => {
                    setSubmittedReport(null);
                    setSuccessMsg(null);
                  }}
                  className="inline-flex items-center gap-1 font-medium text-slate-500 hover:text-slate-800 hover:underline"
                >
                  <span>Dismiss</span>
                </button>
              </div>
            </div>
          )}

          {/* Title Field */}
          <div>
            <label htmlFor="issue-title" className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              <FileText className="w-3.5 h-3.5 text-teal" />
              <span>Issue Title <span className="text-red-500">*</span></span>
            </label>
            <input
              id="issue-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g., Deep crater pothole near pedestrian crossing"
              required
              maxLength={120}
              className="w-full px-4 py-3 text-xs sm:text-sm border border-slate-200 rounded-xl bg-slate-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal/30 focus:border-teal transition"
            />
            <p className="text-xs text-slate-400 mt-1">Short summary for municipal responders</p>
          </div>

          {/* Category Field */}
          <div>
            <label htmlFor="issue-category" className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              <Tag className="w-3.5 h-3.5 text-teal" />
              <span>Category <span className="text-red-500">*</span></span>
            </label>
            <select
              id="issue-category"
              value={category}
              onChange={(e) => setCategory(e.target.value as IssueCategory)}
              required
              className="w-full px-4 py-3 text-xs sm:text-sm border border-slate-200 rounded-xl bg-white focus:outline-none focus:ring-2 focus:ring-teal/30 focus:border-teal transition cursor-pointer"
            >
              {CATEGORIES.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {/* Location Field */}
          <div>
            <label htmlFor="issue-location" className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              <MapPin className="w-3.5 h-3.5 text-teal" />
              <span>Location / Landmark <span className="text-red-500">*</span></span>
            </label>
            <input
              id="issue-location"
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g., Corner of 4th Avenue and Market St, outside City Library"
              required
              maxLength={150}
              className="w-full px-4 py-3 text-xs sm:text-sm border border-slate-200 rounded-xl bg-slate-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal/30 focus:border-teal transition"
            />
            <p className="text-xs text-slate-400 mt-1">Specify identifiable road junction or building</p>
          </div>

          {/* Description Field */}
          <div>
            <label htmlFor="issue-description" className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
              <FileText className="w-3.5 h-3.5 text-teal" />
              <span>Detailed Description <span className="text-red-500">*</span></span>
            </label>
            <textarea
              id="issue-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the severity, how long the hazard has existed, and any immediate danger to motorists or pedestrians..."
              required
              rows={4}
              maxLength={1000}
              className="w-full px-4 py-3 text-xs sm:text-sm border border-slate-200 rounded-xl bg-slate-50/50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-teal/30 focus:border-teal transition"
            />
          </div>

          {/* Submit Action */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={loading}
              className="motion-button w-full sm:w-auto px-7 py-3.5 bg-gradient-to-r from-teal to-teal-700 hover:from-teal-600 hover:to-teal-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-[0_4px_15px_rgba(13,148,136,0.3)] hover:shadow-[0_6px_20px_rgba(13,148,136,0.5)] flex items-center justify-center gap-2.5 disabled:opacity-60"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-[#A3E635]" />
                  <span>Submitting to CivicOS...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 text-[#A3E635]" />
                  <span>Submit Public Grievance</span>
                </>
              )}
            </button>
          </div>

        </form>
      </div>

      {/* Duplicate Report Alert Modal */}
      {showDuplicateAlert && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="duplicate-modal-title"
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto motion-reveal"
        >
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-[0_25px_60px_rgba(15,23,42,0.25)] max-w-2xl w-full p-6 sm:p-8 space-y-6 my-8">
            
            {/* Alert Header */}
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 flex-shrink-0 mt-0.5 shadow-sm">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700 bg-amber-50 px-2.5 py-0.5 rounded-full border border-amber-200 inline-block mb-1">
                  Duplicate Check Notice
                </span>
                <h3 id="duplicate-modal-title" className="text-xl sm:text-2xl font-black text-navy tracking-tight">
                  Potential Similar Reports Found
                </h3>
                <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                  We found <strong>{potentialDuplicates.length}</strong> existing {potentialDuplicates.length === 1 ? 'report' : 'reports'} in the <strong>{category}</strong> category near your specified location. Please review them to avoid creating duplicate civic grievances.
                </p>
              </div>
            </div>

            {/* Suggested Existing Reports List */}
            <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
              {potentialDuplicates.map((dup) => (
                <div
                  key={dup.id}
                  className="bg-slate-50/80 rounded-2xl border border-slate-200/90 p-4 space-y-2.5 transition-all hover:bg-white hover:shadow-sm"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono text-xs font-bold text-teal bg-teal-50 px-2 py-0.5 rounded border border-teal-200/80 flex items-center gap-1">
                        <Hash className="w-3 h-3" />
                        <span className="truncate max-w-[140px]" title={dup.id}>{dup.id}</span>
                      </span>
                      <span className="text-[11px] font-semibold text-slate-600 bg-slate-200/70 px-2 py-0.5 rounded">
                        {dup.category}
                      </span>
                      {isDemo && (
                        <span className="text-[10px] uppercase font-bold text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded border border-slate-200">
                          Demo Sample
                        </span>
                      )}
                    </div>
                    <StatusBadge status={dup.status} />
                  </div>

                  <h4 className="text-sm font-bold text-navy leading-snug">
                    {dup.title}
                  </h4>

                  {dup.description && (
                    <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
                      {dup.description}
                    </p>
                  )}

                  <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200/60 text-xs text-slate-500">
                    <div className="flex items-center gap-1 max-w-[65%]">
                      <MapPin className="w-3.5 h-3.5 text-teal flex-shrink-0" />
                      <span className="truncate text-[11px]" title={dup.location}>{dup.location || 'Location not specified'}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] text-slate-400">{formatDate(dup.created_at)}</span>
                      <button
                        type="button"
                        onClick={() => {
                          setShowDuplicateAlert(false);
                          onNavigate('tracking');
                        }}
                        className="inline-flex items-center gap-1 text-[11px] font-bold text-teal hover:underline"
                        title="View report tracking details"
                      >
                        <span>View in Tracking Desk</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* User Control Actions */}
            <div className="pt-3 border-t border-slate-100 flex flex-col-reverse sm:flex-row items-center justify-end gap-3">
              <button
                type="button"
                onClick={handleCancelAlert}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-100 active:scale-95 text-xs font-semibold transition"
              >
                Return to Form &amp; Edit
              </button>

              <button
                type="button"
                onClick={handleConfirmSubmitAnyway}
                disabled={loading}
                className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal to-teal-700 hover:from-teal-600 hover:to-teal-800 text-white font-bold text-xs shadow-md hover:shadow-lg active:scale-95 transition flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin text-[#A3E635]" />
                    <span>Submitting...</span>
                  </>
                ) : (
                  <>
                    <span>Continue Submitting Anyway</span>
                    <ArrowRight className="w-4 h-4 text-[#A3E635]" />
                  </>
                )}
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
