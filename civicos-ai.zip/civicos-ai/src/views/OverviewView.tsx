import React from 'react';
import { Issue, ViewType } from '../types';
import { IssueCard } from '../components/IssueCard';
import { CitySkylineIllustration } from '../components/CityIllustration';
import { CountUpNumber } from '../components/CountUpNumber';
import { CategoryBarChart } from '../components/CategoryBarChart';
import { StatusDonutChart } from '../components/StatusDonutChart';
import { ReportsTimelineChart } from '../components/ReportsTimelineChart';
import {
  FileText,
  AlertCircle,
  Clock,
  CheckCircle2,
  PlusCircle,
  ArrowRight,
  ShieldCheck,
  Compass,
  Building,
  TrendingUp,
} from 'lucide-react';

interface Props {
  issues: Issue[];
  loading: boolean;
  error: string | null;
  onNavigate: (view: ViewType) => void;
  isDemo: boolean;
}

export const OverviewView: React.FC<Props> = ({
  issues,
  loading,
  error,
  onNavigate,
  isDemo,
}) => {
  const totalCount = issues.length;
  const reportedCount = issues.filter((i) => i.status === 'Reported').length;
  const inProgressCount = issues.filter((i) => i.status === 'In Progress').length;
  const resolvedCount = issues.filter((i) => i.status === 'Resolved').length;

  const newestReports = [...issues]
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .slice(0, 3);

  const resolutionRate = totalCount > 0 ? Math.round((resolvedCount / totalCount) * 100) : 0;

  return (
    <div className="w-full space-y-8 sm:space-y-10">
      
      {/* Hero Section with Modern Motion Entrance */}
      <div className="motion-reveal relative w-full overflow-hidden rounded-3xl bg-gradient-to-br from-[#0F172A] via-[#111e38] to-[#0A0F1D] text-white p-6 sm:p-10 lg:p-12 shadow-[0_20px_50px_rgba(15,23,42,0.22)] border border-slate-800 transition-all duration-300">
        
        {/* Subtle background glow effect */}
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-teal/15 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-1/2 -right-24 w-96 h-96 bg-lime/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* City Skyline Vector with calm beacon */}
        <div className="absolute bottom-0 left-0 right-0 pointer-events-none opacity-45">
          <CitySkylineIllustration className="w-full h-28 sm:h-44 text-slate-700/50" />
        </div>

        <div className="relative z-10 max-w-3xl">
          {/* Badge */}
          <div className="motion-reveal motion-delay-1 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold bg-teal/20 text-[#A3E635] border border-teal/40 shadow-inner mb-4">
            <ShieldCheck className="w-4 h-4 text-[#A3E635]" />
            <span>CIVICOS AI · CIVIC INTELLIGENCE</span>
          </div>

          {/* Heading */}
          <h1 className="motion-reveal motion-delay-2 text-2xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white mb-4 leading-tight">
            Building Better <br className="hidden sm:inline" />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-teal-400 to-[#A3E635]">
              Communities
            </span>
          </h1>

          {/* Subheading */}
          <p className="motion-reveal motion-delay-3 text-xs sm:text-base text-slate-300 mb-8 leading-relaxed max-w-2xl">
            CivicOS AI helps citizens report local hazards, track resolution progress with full municipal transparency, and explore community issues together in real time.
          </p>

          {/* Hero CTAs */}
          <div className="motion-reveal motion-delay-4 flex flex-wrap items-center gap-3 sm:gap-4">
            <button
              onClick={() => onNavigate('report')}
              className="motion-button inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-teal to-teal-700 hover:from-teal-600 hover:to-teal-800 text-white text-xs sm:text-sm font-bold shadow-[0_4px_15px_rgba(13,148,136,0.4)] hover:shadow-[0_8px_25px_rgba(13,148,136,0.6)]"
            >
              <PlusCircle className="w-4 h-4 text-[#A3E635]" />
              <span>Report an Issue</span>
            </button>

            <button
              onClick={() => onNavigate('explore')}
              className="motion-button inline-flex items-center justify-center gap-2 px-5 py-3.5 rounded-xl bg-slate-800/90 hover:bg-slate-700 text-slate-200 hover:text-white text-xs sm:text-sm font-semibold border border-slate-700/80 backdrop-blur-sm"
            >
              <Compass className="w-4 h-4 text-teal" />
              <span>Explore Public Reports</span>
            </button>

            {/* Quick Micro-stat pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900/60 border border-slate-800 text-xs text-slate-300">
              <TrendingUp className="w-3.5 h-3.5 text-[#A3E635]" />
              <span>
                <strong>
                  <CountUpNumber target={resolutionRate} />%
                </strong> resolution rate
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Metrics Row with Animated Count-Up Numbers */}
      <div className="motion-reveal motion-delay-2 w-full">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Building className="w-4 h-4 text-teal" />
            <h2 className="text-xs font-bold text-slate-600 uppercase tracking-wider">
              Live Municipal Triage Statistics
            </h2>
          </div>
          <span className="text-xs text-slate-400">Live system counters</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 w-full">
          
          {/* Total Reports */}
          <div className="group bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-[0_2px_10px_rgba(15,23,42,0.03)] hover:shadow-[0_12px_28px_rgba(15,23,42,0.08)] motion-card">
            <div className="flex items-center justify-between text-slate-500 mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Total Reports</span>
              <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600 group-hover:bg-slate-200 transition-colors">
                <FileText className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl sm:text-4xl font-black text-navy tracking-tight">
              {loading ? '...' : <CountUpNumber target={totalCount} />}
            </div>
            <p className="text-xs text-slate-400 mt-2 font-medium">Logged citizen issues</p>
          </div>

          {/* Reported */}
          <div className="group bg-white rounded-2xl border border-amber-200/90 p-5 sm:p-6 shadow-[0_2px_10px_rgba(245,158,11,0.04)] hover:shadow-[0_12px_28px_rgba(245,158,11,0.12)] motion-card">
            <div className="flex items-center justify-between text-amber-700 mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-700">Reported</span>
              <div className="w-8 h-8 rounded-lg bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 group-hover:scale-105 transition-transform">
                <AlertCircle className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl sm:text-4xl font-black text-amber-900 tracking-tight">
              {loading ? '...' : <CountUpNumber target={reportedCount} />}
            </div>
            <p className="text-xs text-amber-700/80 mt-2 font-medium">Awaiting city review</p>
          </div>

          {/* In Progress */}
          <div className="group bg-white rounded-2xl border border-teal-200/90 p-5 sm:p-6 shadow-[0_2px_10px_rgba(13,148,136,0.04)] hover:shadow-[0_12px_28px_rgba(13,148,136,0.12)] motion-card">
            <div className="flex items-center justify-between text-teal mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-teal">In Progress</span>
              <div className="w-8 h-8 rounded-lg bg-teal-50 border border-teal-200 flex items-center justify-center text-teal group-hover:scale-105 transition-transform">
                <Clock className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl sm:text-4xl font-black text-teal tracking-tight">
              {loading ? '...' : <CountUpNumber target={inProgressCount} />}
            </div>
            <p className="text-xs text-teal/80 mt-2 font-medium">Field crews deployed</p>
          </div>

          {/* Resolved */}
          <div className="group bg-white rounded-2xl border border-emerald-200/90 p-5 sm:p-6 shadow-[0_2px_10px_rgba(16,185,129,0.04)] hover:shadow-[0_12px_28px_rgba(16,185,129,0.12)] motion-card">
            <div className="flex items-center justify-between text-emerald-700 mb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">Resolved</span>
              <div className="w-8 h-8 rounded-lg bg-emerald-50 border border-emerald-200 flex items-center justify-center text-emerald-600 group-hover:scale-105 transition-transform">
                <CheckCircle2 className="w-4 h-4" />
              </div>
            </div>
            <div className="text-3xl sm:text-4xl font-black text-emerald-900 tracking-tight">
              {loading ? '...' : <CountUpNumber target={resolvedCount} />}
            </div>
            <p className="text-xs text-emerald-700/80 mt-2 font-medium">Verified fixed & closed</p>
          </div>

        </div>
      </div>

      {/* Visual Analytics Section */}
      <div className="motion-reveal motion-delay-3 w-full space-y-5 sm:space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 sm:gap-6">
          <CategoryBarChart issues={issues} onNavigate={onNavigate} />
          <StatusDonutChart
            issues={issues}
            reported={reportedCount}
            inProgress={inProgressCount}
            resolved={resolvedCount}
            onNavigate={onNavigate}
          />
        </div>

        {/* Reports Activity Over Time (Date-based column histogram from genuine timestamps) */}
        <ReportsTimelineChart issues={issues} onNavigate={onNavigate} />
      </div>

      {/* Newest Reports Section */}
      <div className="motion-reveal motion-delay-4 w-full space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-navy">Newest Citizen Reports</h2>
            <p className="text-xs text-slate-500">Recently registered grievances and infrastructure requests</p>
          </div>
          <button
            onClick={() => onNavigate('explore')}
            className="motion-button self-start sm:self-auto text-xs font-bold text-teal hover:text-teal-700 inline-flex items-center gap-1.5 py-2 px-3.5 rounded-xl bg-teal-50 hover:bg-teal-100 border border-teal-200/80 shadow-sm group"
          >
            <span>View All Reports</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        {loading ? (
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-12 text-center text-slate-500 text-xs">
            Loading recent reports...
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 rounded-2xl p-5 text-xs text-red-700 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Unable to load reports</p>
              <p className="mt-1 text-red-600">{error}</p>
            </div>
          </div>
        ) : newestReports.length === 0 ? (
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-12 text-center text-slate-500">
            <p className="text-xs font-semibold text-navy">No reports have been registered yet.</p>
            <button
              onClick={() => onNavigate('report')}
              className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-teal text-white rounded-xl text-xs font-semibold hover:bg-teal-700 shadow-sm active:scale-95 transition-all"
            >
              <PlusCircle className="w-3.5 h-3.5" /> Be the first to report an issue
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6 w-full">
            {newestReports.map((issue) => (
              <IssueCard key={issue.id} issue={issue} isDemo={isDemo} />
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
