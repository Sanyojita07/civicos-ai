import React, { useState } from 'react';
import { ViewType } from '../types';
import {
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  HelpCircle,
  ChevronDown,
  ArrowRight,
  Shield,
  Trash2,
  Construction,
  Droplet,
  Lightbulb,
  Building,
  Search,
  Info,
  Clock,
} from 'lucide-react';

interface Props {
  onNavigate: (view: ViewType) => void;
  isDemo: boolean;
}

interface FAQItem {
  id: string;
  question: string;
  answer: React.ReactNode;
}

export const GuidelinesView: React.FC<Props> = ({ onNavigate }) => {
  // Accordion open/close state
  const [openFaq, setOpenFaq] = useState<string | null>('faq-1');

  const toggleFaq = (id: string) => {
    setOpenFaq((prev) => (prev === id ? null : id));
  };

  const categories = [
    {
      title: 'Pothole & Road Hazards',
      desc: 'Craters, road cave-ins, broken asphalt, and hazardous street openings.',
      formCategory: 'Pothole/Road',
      icon: <Construction className="w-5 h-5 text-orange-600" />,
      bg: 'bg-orange-50 border-orange-200/80',
    },
    {
      title: 'Garbage & Sanitation',
      desc: 'Overflowing public bins, unauthorized waste dumping, and litter buildup.',
      formCategory: 'Garbage',
      icon: <Trash2 className="w-5 h-5 text-amber-600" />,
      bg: 'bg-amber-50 border-amber-200/80',
    },
    {
      title: 'Water Leakage & Mains',
      desc: 'Burst municipal supply pipes, roadway flooding, and sewer blockages.',
      formCategory: 'Water Leakage',
      icon: <Droplet className="w-5 h-5 text-cyan-600" />,
      bg: 'bg-cyan-50 border-cyan-200/80',
    },
    {
      title: 'Broken Streetlights',
      desc: 'Non-functional night lamps, dark corridors, flickering fixtures, or dangling wiring.',
      formCategory: 'Streetlight',
      icon: <Lightbulb className="w-5 h-5 text-yellow-600" />,
      bg: 'bg-yellow-50 border-yellow-200/80',
    },
    {
      title: 'Drainage Problems',
      desc: 'Clogged storm drains, standing water accumulation, or overflowing gutters.',
      formCategory: 'Other',
      icon: <Building className="w-5 h-5 text-teal" />,
      bg: 'bg-teal-50 border-teal-200/80',
      note: 'Report under "Other"',
    },
    {
      title: 'Damaged Public Infrastructure',
      desc: 'Broken sidewalk guardrails, damaged transit stops, fallen poles, or parks damage.',
      formCategory: 'Other',
      icon: <Shield className="w-5 h-5 text-indigo-600" />,
      bg: 'bg-indigo-50 border-indigo-200/80',
      note: 'Report under "Other"',
    },
  ];

  const steps = [
    {
      num: '01',
      title: 'Open "Report an Issue"',
      desc: 'Navigate to the reporting portal using the main navigation or quick action button.',
      action: () => onNavigate('report'),
      actionLabel: 'Go to Report form',
    },
    {
      num: '02',
      title: 'Select Category',
      desc: 'Choose the most fitting issue type (Garbage, Pothole/Road, Water Leakage, Streetlight, or Other).',
    },
    {
      num: '03',
      title: 'Write Clear Description',
      desc: 'Specify the severity, duration, and safety hazards accurately without emotional or abusive language.',
    },
    {
      num: '04',
      title: 'Provide Accurate Location',
      desc: 'Input recognizable street names, intersection crossings, or public landmark references.',
    },
    {
      num: '05',
      title: 'Submit the Report',
      desc: 'Verify the details and submit. Note: image uploads are not currently required or supported by the form.',
    },
    {
      num: '06',
      title: 'Save Your Report ID',
      desc: 'A unique reference UUID is generated upon confirmation. Keep this ID for tracking your report status.',
    },
  ];

  const guidelines = [
    {
      title: 'Submit Truthful & Accurate Information',
      desc: 'Provide honest details about what is observed. Exaggerating hazards or submitting fictitious reports undermines public resources.',
      type: 'do',
    },
    {
      title: 'Identify Locations With Identifiable Landmarks',
      desc: 'Use recognizable street intersections, public buildings, or house numbering nearby so responders can locate the issue.',
      type: 'do',
    },
    {
      title: 'Check Existing Reports Before Posting',
      desc: 'Use Explore Reports or Tracking to check whether an issue in your sector is already logged to avoid unnecessary duplicate complaints.',
      type: 'do',
    },
    {
      title: 'Respect Personal Privacy',
      desc: 'Never enter private cell phone numbers, personal door numbers, vehicle plates, or sensitive personal data into public reports.',
      type: 'caution',
    },
    {
      title: 'Zero Tolerance for Harassment',
      desc: 'Do not use abusive, threatening, or defamatory language. CivicOS is an open civic accountability workspace.',
      type: 'caution',
    },
    {
      title: 'Not for Emergency Services',
      desc: 'CivicOS AI is not an emergency dispatch. For active fires, gas leaks, crimes, or medical crises, dial local emergency services immediately.',
      type: 'emergency',
    },
  ];

  const faqs: FAQItem[] = [
    {
      id: 'faq-1',
      question: 'Where can I find my Report ID?',
      answer: (
        <p>
          Immediately after submitting a report through the <strong>Report an Issue</strong> page, the green confirmation banner displays your unique reference UUID (e.g., <code className="bg-slate-100 px-1.5 py-0.5 rounded font-mono text-xs">c8f1e42a-...</code>). Additionally, you can always look up your recent submissions in <strong>My Reports</strong> or inspect any report via the <strong>Track Reports</strong> desk.
        </p>
      ),
    },
    {
      id: 'faq-2',
      question: 'What does "Reported" mean?',
      answer: (
        <p>
          The <strong>Reported</strong> status confirms that your submission has been validated and recorded in the CivicOS database or local demo session. It signifies public registration; it does <em>not</em> confirm that a municipal agency or staff officer has reviewed, approved, or scheduled action on it.
        </p>
      ),
    },
    {
      id: 'faq-3',
      question: 'How can I check my reports?',
      answer: (
        <p>
          You have two dedicated options:
          <br />
          1. <strong>My Reports</strong>: Displays your own submitted issues (retrieved via authenticated Supabase user profile, or from browser <code className="bg-slate-100 px-1 py-0.5 rounded text-xs">localStorage</code> for guests).
          <br />
          2. <strong>Track Reports</strong>: Allows anyone to search any report by its unique Report ID and inspect its verified progress timeline and status.
        </p>
      ),
    },
    {
      id: 'faq-4',
      question: 'What does Demo Mode mean?',
      answer: (
        <p>
          When Supabase environment variables (<code className="bg-slate-100 px-1 py-0.5 rounded text-xs">VITE_SUPABASE_URL</code> &amp; <code className="bg-slate-100 px-1 py-0.5 rounded text-xs">VITE_SUPABASE_PUBLISHABLE_KEY</code>) are unconfigured, CivicOS AI operates in <strong>Demo Mode</strong> with verified sample civic records. Submissions are kept in local memory for demonstration and will not persist to a cloud database.
        </p>
      ),
    },
    {
      id: 'faq-5',
      question: 'Will my issue definitely be resolved?',
      answer: (
        <p>
          Submitting a civic issue to CivicOS AI provides public visibility and record-keeping, but <strong>does not guarantee official resolution, municipal action, or guaranteed department response</strong>. The platform empowers citizen reporting and community tracking.
        </p>
      ),
    },
    {
      id: 'faq-6',
      question: 'How do I avoid duplicate reports?',
      answer: (
        <p>
          Before filing a new complaint, visit the <strong>Explore Reports</strong> or <strong>Track Reports</strong> pages. You can search by your street name, landmark, or category to see if your neighbors have already registered the incident.
        </p>
      ),
    },
  ];

  return (
    <div className="w-full space-y-10 sm:space-y-12 motion-reveal">
      {/* Hero Section */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-[#0F172A] via-[#111e38] to-[#0A0F1D] text-white p-7 sm:p-10 lg:p-12 shadow-[0_20px_50px_rgba(15,23,42,0.22)] border border-slate-800">
        {/* Subtle background glow effect */}
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-teal/15 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute top-1/2 -right-24 w-96 h-96 bg-lime/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 max-w-3xl">
          {/* Eyebrow Badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold bg-teal/20 text-[#A3E635] border border-teal/40 shadow-inner mb-4">
            <BookOpen className="w-4 h-4 text-[#A3E635]" />
            <span>CIVIC KNOWLEDGE &amp; STANDARDS</span>
          </div>

          {/* Main Heading with cyan-to-green gradient accent */}
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white mb-4 leading-tight">
            Community &amp; <span className="text-transparent bg-clip-text bg-gradient-to-r from-teal-300 via-teal-400 to-[#A3E635]">Guidelines</span>
          </h1>

          {/* Subtitle Description */}
          <p className="text-xs sm:text-base text-slate-300 leading-relaxed max-w-2xl">
            Accurate civic reports help communities identify public issues, prioritize neighborhood maintenance, and foster transparent local accountability. Learn what can be reported, how the reporting workflow works, and how to follow community standards.
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-6">
            <button
              onClick={() => onNavigate('report')}
              className="motion-button inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-teal to-teal-700 hover:from-teal-600 hover:to-teal-800 text-white text-xs sm:text-sm font-bold shadow-md hover:shadow-lg transition-all active:scale-95 focus:outline-none focus:ring-2 focus:ring-teal/40"
            >
              <span>Submit a Report &rarr;</span>
            </button>
            <button
              onClick={() => onNavigate('tracking')}
              className="motion-button inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs sm:text-sm font-semibold border border-slate-700 transition-all active:scale-95 focus:outline-none focus:ring-2 focus:ring-slate-600"
            >
              <Search className="w-4 h-4 text-teal" />
              <span>Track an Existing Report</span>
            </button>
          </div>
        </div>
      </div>

      {/* Section A: What Can You Report? */}
      <section className="motion-reveal motion-delay-1 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-teal">Scope &amp; Categories</span>
            <h2 className="text-xl sm:text-2xl font-black text-navy">What Can You Report?</h2>
          </div>
          <p className="text-xs text-slate-500 max-w-md">
            The platform supports five core categories in the reporting form. Issues outside roads, waste, lights, or water can be logged under "Other".
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
          {categories.map((cat, idx) => (
            <div
              key={idx}
              className="motion-card bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-sm flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${cat.bg}`}>
                    {cat.icon}
                  </div>
                  <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                    Form: {cat.formCategory}
                  </span>
                </div>
                <h3 className="text-base font-bold text-navy mb-1.5">{cat.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed mb-3">{cat.desc}</p>
              </div>

              {cat.note && (
                <div className="pt-2 border-t border-slate-100 text-[11px] text-teal font-medium flex items-center gap-1">
                  <Info className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>{cat.note}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Section B: How to Report an Issue */}
      <section className="motion-reveal motion-delay-2 space-y-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal">Step-by-Step Guide</span>
          <h2 className="text-xl sm:text-2xl font-black text-navy">How to Report an Issue</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Follow this simple process to ensure your civic report has the details needed for tracking.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
          {steps.map((st, idx) => (
            <div
              key={idx}
              className="motion-card bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-sm flex flex-col justify-between relative"
            >
              <div>
                <span className="text-2xl font-black text-teal/40 block mb-2 font-mono">{st.num}</span>
                <h3 className="text-sm font-bold text-navy mb-1.5">{st.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{st.desc}</p>
              </div>

              {st.action && (
                <div className="mt-4 pt-3 border-t border-slate-100">
                  <button
                    onClick={st.action}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-teal hover:underline"
                  >
                    <span>{st.actionLabel}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Section C: Community Guidelines */}
      <section className="motion-reveal motion-delay-3 space-y-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal">Standards &amp; Expectations</span>
          <h2 className="text-xl sm:text-2xl font-black text-navy">Community Standards</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            CivicOS AI is maintained as a transparent, respectful public utility. Please review our submission guidelines.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5">
          {guidelines.map((g, idx) => {
            const isEmergency = g.type === 'emergency';
            const isCaution = g.type === 'caution';

            return (
              <div
                key={idx}
                className={`motion-card rounded-2xl border p-5 sm:p-6 shadow-sm flex flex-col justify-between ${
                  isEmergency
                    ? 'bg-rose-50/80 border-rose-200 text-rose-950'
                    : isCaution
                    ? 'bg-amber-50/80 border-amber-200 text-amber-950'
                    : 'bg-white border-slate-200/90 text-navy'
                }`}
              >
                <div className="flex items-center gap-2 mb-2.5">
                  {isEmergency ? (
                    <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0" />
                  ) : isCaution ? (
                    <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 text-teal flex-shrink-0" />
                  )}
                  <h3 className="text-sm font-bold">{g.title}</h3>
                </div>
                <p
                  className={`text-xs leading-relaxed ${
                    isEmergency
                      ? 'text-rose-900/90'
                      : isCaution
                      ? 'text-amber-900/90'
                      : 'text-slate-600'
                  }`}
                >
                  {g.desc}
                </p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Section E: What Happens Next? (Workflow expectations) */}
      <section className="motion-reveal motion-delay-3 bg-gradient-to-r from-slate-900 via-navy to-slate-900 text-white rounded-3xl p-6 sm:p-8 border border-slate-800 shadow-md">
        <div className="max-w-3xl space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-teal/20 text-[#A3E635] border border-teal/40">
            <Clock className="w-3.5 h-3.5" />
            <span>Workflow &amp; Life Cycle</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-white">What Happens After You Submit?</h2>

          <div className="space-y-3 text-xs sm:text-sm text-slate-300 leading-relaxed">
            <p>
              1. <strong>Instant Confirmation &amp; Reference ID</strong>: When you submit a valid report, CivicOS returns a unique Report ID UUID. Copy or save this ID for tracking.
            </p>
            <p>
              2. <strong>Public Visibility</strong>: Your issue becomes indexed and queryable in <strong>Explore Reports</strong> and the <strong>Live Tracking Desk</strong>.
            </p>
            <p>
              3. <strong>Verified Data Only</strong>: Any progress status (e.g., <em>Reported</em>, <em>In Progress</em>, <em>Resolved</em>) displayed in the application reflects actual saved records in the database. The system does not manufacture fake intermediate events or guarantee municipal dispatch.
            </p>
            <p className="text-amber-300/90 font-medium pt-1">
              * Note: Filing an issue records your grievance publicly for transparent community tracking, but does not guarantee official municipal intervention or resolution.
            </p>
          </div>
        </div>
      </section>

      {/* Section D: Interactive FAQs Accordion */}
      <section className="motion-reveal motion-delay-4 space-y-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-teal">Frequently Asked Questions</span>
          <h2 className="text-xl sm:text-2xl font-black text-navy">Interactive FAQs</h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Click any question to view clear, transparent answers about the platform.
          </p>
        </div>

        <div className="space-y-3">
          {faqs.map((faq) => {
            const isOpen = openFaq === faq.id;

            return (
              <div
                key={faq.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-sm overflow-hidden transition-all"
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(faq.id)}
                  aria-expanded={isOpen}
                  className="w-full text-left p-5 flex items-center justify-between gap-4 hover:bg-slate-50/60 transition focus:outline-none focus:ring-2 focus:ring-teal/30"
                >
                  <div className="flex items-center gap-3">
                    <HelpCircle className="w-4 h-4 text-teal flex-shrink-0" />
                    <span className="text-xs sm:text-sm font-bold text-navy">{faq.question}</span>
                  </div>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 flex-shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-teal' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="motion-expand px-5 pb-5 pt-1 text-xs text-slate-600 leading-relaxed border-t border-slate-100/80 bg-slate-50/40">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
};
