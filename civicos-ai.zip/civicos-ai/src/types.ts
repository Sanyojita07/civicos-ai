export type IssueCategory = 'Garbage' | 'Pothole/Road' | 'Water Leakage' | 'Streetlight' | 'Other';

export type IssueStatus = 'Reported' | 'In Progress' | 'Resolved' | 'Under Review';

export interface Issue {
  id: string;
  user_id: string | null;
  title: string;
  description: string;
  category: IssueCategory;
  location: string;
  status: IssueStatus;
  created_at: string;
}

export type ViewType = 'overview' | 'report' | 'explore' | 'my-reports' | 'tracking' | 'guidelines';
