import React, { useEffect, useState } from 'react';

interface Props {
  target: number;
  duration?: number;
  className?: string;
}

export const CountUpNumber: React.FC<Props> = ({ target, duration = 1200, className }) => {
  const [count, setCount] = useState<number>(0);

  useEffect(() => {
    // Respect prefers-reduced-motion
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setCount(target);
      return;
    }

    const end = target;
    if (end === 0) {
      setCount(0);
      return;
    }

    const startTime = performance.now();

    const updateCount = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      
      // easeOutExpo for professional digital counter effect
      const ease = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      const current = Math.floor(ease * end);
      
      setCount(current);

      if (progress < 1) {
        requestAnimationFrame(updateCount);
      } else {
        setCount(end);
      }
    };

    const frameId = requestAnimationFrame(updateCount);
    return () => cancelAnimationFrame(frameId);
  }, [target, duration]);

  return <span className={className}>{count}</span>;
};
