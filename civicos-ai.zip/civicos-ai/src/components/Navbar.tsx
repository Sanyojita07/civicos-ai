import React from 'react';
import { ViewType } from '../types';
import {
  Building2,
  PlusCircle,
  Compass,
  FolderCheck,
  Menu,
  X,
  LogIn,
  LogOut,
  User,
  Sparkles,
  Activity,
  BookOpen,
} from 'lucide-react';

interface Props {
  currentView: ViewType;
  onNavigate: (view: ViewType) => void;
  userEmail: string | null;
  onOpenAuth: () => void;
  onSignOut: () => void;
  isDemo: boolean;
}

export const Navbar: React.FC<Props> = ({
  currentView,
  onNavigate,
  userEmail,
  onOpenAuth,
  onSignOut,
  isDemo,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navItems: { view: ViewType; label: string; icon: React.ReactNode }[] = [
    { view: 'overview', label: 'Overview', icon: <Building2 className="w-4 h-4" /> },
    { view: 'report', label: 'Report an Issue', icon: <PlusCircle className="w-4 h-4" /> },
    { view: 'explore', label: 'Explore Reports', icon: <Compass className="w-4 h-4" /> },
    { view: 'my-reports', label: 'My Reports', icon: <FolderCheck className="w-4 h-4" /> },
    { view: 'tracking', label: 'Tracking Reports', icon: <Activity className="w-4 h-4" /> },
    { view: 'guidelines', label: 'Community & Guidelines', icon: <BookOpen className="w-4 h-4" /> },
  ];

  const handleNavClick = (view: ViewType) => {
    onNavigate(view);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#0F172A]/95 backdrop-blur-md border-b border-slate-800 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          
          {/* Logo / Brand */}
          <div
            role="button"
            tabIndex={0}
            onClick={() => handleNavClick('overview')}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleNavClick('overview');
              }
            }}
            aria-label="CivicOS AI Home"
            className="flex items-center gap-3 cursor-pointer group select-none transition-transform active:scale-95 duration-150 focus:outline-none focus:ring-2 focus:ring-teal/40 rounded-xl"
          >
            <div className="relative">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-teal via-teal-600 to-[#14b8a6] flex items-center justify-center font-black text-white text-lg tracking-wider shadow-[0_0_15px_rgba(13,148,136,0.4)] group-hover:shadow-[0_0_22px_rgba(163,230,53,0.6)] group-hover:rotate-1 transition-all duration-200">
                C
              </div>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-navy border-2 border-slate-900 flex items-center justify-center">
                <div className="w-2 h-2 rounded-full bg-lime pulse-indicator"></div>
              </div>
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-white group-hover:text-slate-100 transition">
                  CivicOS
                </span>
                <span className="text-xs font-black px-2 py-0.5 rounded-md bg-[#A3E635]/15 text-[#A3E635] border border-[#A3E635]/30 flex items-center gap-1 group-hover:bg-[#A3E635]/25 transition">
                  <Sparkles className="w-3 h-3 text-[#A3E635]" />
                  AI
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium tracking-wide hidden sm:block">
                Municipal Intelligence & Action
              </p>
            </div>
          </div>

          {/* Desktop Navigation links with smooth hover indicators */}
          <nav className="hidden md:flex items-center space-x-1.5 lg:space-x-2 bg-slate-900/60 p-1.5 rounded-xl border border-slate-800">
            {navItems.map((item) => {
              const isActive = currentView === item.view;
              return (
                <button
                  key={item.view}
                  onClick={() => handleNavClick(item.view)}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-semibold transition-all duration-200 active:scale-95 ${
                    isActive
                      ? 'bg-gradient-to-r from-teal to-teal-700 text-white shadow-[0_2px_10px_rgba(13,148,136,0.35)]'
                      : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                  }`}
                >
                  {item.icon}
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* User / Auth section */}
          <div className="hidden md:flex items-center space-x-3">
            {isDemo ? (
              <div className="flex items-center gap-2 bg-slate-800/90 text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700/80 text-xs font-medium">
                <span className="w-2 h-2 rounded-full bg-amber-400 pulse-indicator"></span>
                <span>Demo Workspace</span>
              </div>
            ) : userEmail ? (
              <div className="flex items-center gap-2.5">
                <div className="flex items-center gap-2 text-xs text-slate-200 bg-slate-800/90 px-3 py-1.5 rounded-xl border border-slate-700">
                  <div className="w-6 h-6 rounded-full bg-teal/20 text-lime flex items-center justify-center font-bold">
                    <User className="w-3.5 h-3.5" />
                  </div>
                  <span className="max-w-[130px] truncate font-medium" title={userEmail}>
                    {userEmail}
                  </span>
                </div>
                <button
                  onClick={onSignOut}
                  className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-rose-300 hover:bg-slate-800 active:scale-95 px-2.5 py-1.5 rounded-lg border border-slate-700/80 transition-all duration-150"
                  title="Sign Out"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span className="hidden lg:inline">Sign Out</span>
                </button>
              </div>
            ) : (
              <button
                onClick={onOpenAuth}
                className="flex items-center gap-2 text-xs font-bold bg-gradient-to-r from-teal to-teal-700 hover:from-teal-700 hover:to-teal-800 active:scale-95 text-white px-4 py-2 rounded-xl transition-all duration-150 shadow-[0_2px_8px_rgba(13,148,136,0.25)] hover:shadow-[0_4px_12px_rgba(13,148,136,0.4)] border border-teal-500/30"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Citizen Sign In</span>
              </button>
            )}
          </div>

          {/* Mobile hamburger button */}
          <div className="flex items-center md:hidden gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg text-slate-300 hover:text-white hover:bg-slate-800 focus:outline-none transition-colors active:scale-90"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0F172A] border-b border-slate-800 px-4 pt-2 pb-5 space-y-2 anim-fade-up">
          {navItems.map((item) => {
            const isActive = currentView === item.view;
            return (
              <button
                key={item.view}
                onClick={() => handleNavClick(item.view)}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-xs font-semibold text-left transition-colors active:scale-95 ${
                  isActive
                    ? 'bg-teal text-white shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800'
                }`}
              >
                {item.icon}
                {item.label}
              </button>
            );
          })}

          <div className="pt-3 border-t border-slate-800">
            {isDemo ? (
              <p className="text-xs text-slate-400 px-3 py-1">
                Demo Mode: Connect Supabase for live multi-user authentication.
              </p>
            ) : userEmail ? (
              <div className="space-y-2 px-1">
                <div className="text-xs text-slate-300 truncate py-1">
                  Signed in as: <strong className="text-lime">{userEmail}</strong>
                </div>
                <button
                  onClick={() => {
                    onSignOut();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full flex items-center justify-center gap-2 text-xs text-red-400 hover:bg-slate-800 active:scale-95 py-2 rounded-lg border border-red-500/20 transition-all"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  Sign Out
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  onOpenAuth();
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-center gap-2 text-xs font-semibold bg-teal hover:bg-teal-700 active:scale-95 text-white py-2.5 rounded-lg transition-all"
              >
                <LogIn className="w-4 h-4" />
                Citizen Sign In / Up
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
