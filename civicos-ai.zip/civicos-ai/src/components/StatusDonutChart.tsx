import React, { useEffect, useState } from 'react';
import { Issue, ViewType } from '../types';
import { PieChart, ArrowRight } from 'lucide-react';

interface Props {
  issues?: Issue[];
  reported?: number;
  inProgress?: number;
  resolved?: number;
  underReview?: number;
  onNavigate?: (view: ViewType) => void;
}

interface SegmentItem {
  status: string;
  label: string;
  count: number;
  color: string;
  dotColor: string;
  description: string;
  badgeBg: string;
}

export const StatusDonutChart: React.FC<Props> = ({
  issues,
  reported,
  inProgress,
  resolved,
  underReview,
  onNavigate,
}) => {
  const [mounted, setMounted] = useState(false);
  const [hoveredStatus, setHoveredStatus] = useState<string | null>(null);

  useEffect(() => {
    // Trigger smooth stroke drawing animation
    const timer = setTimeout(() => setMounted(true), 120);
    return () => clearTimeout(timer);
  }, []);

  // Compute counts from either issues array or explicit count props
  const reportedCount = issues
    ? issues.filter((i) => i.status === 'Reported').length
    : reported || 0;
  const inProgressCount = issues
    ? issues.filter((i) => i.status === 'In Progress').length
    : inProgress || 0;
  const resolvedCount = issues
    ? issues.filter((i) => i.status === 'Resolved').length
    : resolved || 0;
  const underReviewCount = issues
    ? issues.filter((i) => i.status === 'Under Review').length
    : underReview || 0;

  const total = reportedCount + inProgressCount + resolvedCount + underReviewCount;
  const resolutionRate = total > 0 ? Math.round((resolvedCount / total) * 100) : 0;

  const radius = 38;
  const circumference = 2 * Math.PI * radius; // ~238.76

  const segments: SegmentItem[] = [
    {
      status: 'Reported',
      label: 'Reported',
      count: reportedCount,
      color: '#F59E0B',
      dotColor: 'bg-amber-500',
      description: 'Awaiting city review',
      badgeBg: 'bg-amber-50 text-amber-800 border-amber-200',
    },
    {
      status: 'In Progress',
      label: 'In Progress',
      count: inProgressCount,
      color: '#0D9488',
      dotColor: 'bg-teal',
      description: 'Field crews deployed',
      badgeBg: 'bg-teal-50 text-teal-800 border-teal-200',
    },
    {
      status: 'Resolved',
      label: 'Resolved',
      count: resolvedCount,
      color: '#10B981',
      dotColor: 'bg-emerald-500',
      description: 'Verified & closed',
      badgeBg: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    },
  ];

  if (underReviewCount > 0) {
    segments.splice(1, 0, {
      status: 'Under Review',
      label: 'Under Review',
      count: underReviewCount,
      color: '#6366F1',
      dotColor: 'bg-indigo-500',
      description: 'Under administrative assessment',
      badgeBg: 'bg-indigo-50 text-indigo-800 border-indigo-200',
    });
  }

  const handleStatusClick = (status: string) => {
    try {
      sessionStorage.setItem('civicos_filter_status', status);
      sessionStorage.removeItem('civicos_filter_category');
    } catch {
      // sessionStorage safe fallback
    }
    if (onNavigate) {
      onNavigate('explore');
    }
  };

  if (total === 0) {
    return (
      <div className="bg-white rounded-3xl border border-slate-200/90 p-8 shadow-sm text-center flex flex-col items-center justify-center space-y-3">
        <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400">
          <PieChart className="w-6 h-6" />
        </div>
        <div>
          <h3 className="text-sm font-bold text-slate-800">Resolution Status</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-xs">
            No report status data is currently available. Once issues are submitted, lifecycle metrics will appear here.
          </p>
        </div>
      </div>
    );
  }

  // Pre-calculate segment lengths and stroke offsets along the circumference
  const baseOffset = -circumference / 4; // Start at top (-90 deg)
  let accumulatedLength = 0;
  const segmentsWithOffsets = segments.map((seg) => {
    const segLen = total > 0 ? (seg.count / total) * circumference : 0;
    const currentOffset = baseOffset - accumulatedLength;
    if (seg.count > 0) {
      accumulatedLength += segLen;
    }
    const percent = total > 0 ? Math.round((seg.count / total) * 100) : 0;
    return {
      ...seg,
      segLen,
      currentOffset,
      percent,
    };
  });

  const activeSegment = segmentsWithOffsets.find((s) => s.status === hoveredStatus);
  const activePercent = activeSegment ? activeSegment.percent : 0;

  return (
    <div className="bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-7 shadow-[0_4px_20px_rgba(15,23,42,0.04)] hover:shadow-[0_8px_30px_rgba(15,23,42,0.07)] transition-all duration-300 flex flex-col justify-between relative overflow-hidden">
      
      {/* Header */}
      <div>
        <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-600">
                <PieChart className="w-3.5 h-3.5 text-emerald-600" />
              </div>
              <h3 className="text-sm sm:text-base font-black text-navy tracking-tight">
                Resolution Status
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Breakdown of reported issues across lifecycle stages
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 shadow-xs">
              {resolutionRate}% Resolved
            </span>
            {onNavigate && (
              <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold text-teal bg-teal-50/80 px-2.5 py-1 rounded-full border border-teal-200/60">
                Click segment to filter
              </span>
            )}
          </div>
        </div>

        {/* Dynamic Context Tooltip Header */}
        <div className="min-h-[28px] mb-2 flex items-center">
          {activeSegment ? (
            <div className="w-full px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs flex items-center justify-between animate-view-entry shadow-sm">
              <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${activeSegment.dotColor}`} />
                <span className="font-bold">{activeSegment.label}:</span>
                <span className="text-slate-300">
                  {activeSegment.count} {activeSegment.count === 1 ? 'report' : 'reports'} ({activePercent}%)
                </span>
                <span className="hidden md:inline text-slate-400">· {activeSegment.description}</span>
              </div>
              {onNavigate && (
                <span className="text-[#A3E635] text-[11px] font-semibold flex items-center gap-1">
                  View in Explore <ArrowRight className="w-3 h-3" />
                </span>
              )}
            </div>
          ) : (
            <div className="text-[11px] text-slate-400 italic">
              Hover over donut segments or legend cards to inspect details
            </div>
          )}
        </div>

        {/* Donut SVG with Center Readout */}
        <div className="relative flex items-center justify-center py-3 sm:py-4">
          <svg
            viewBox="0 0 100 100"
            className="w-44 h-44 sm:w-48 sm:h-48 transform -rotate-90 filter drop-shadow-xs"
          >
            {/* Background Track */}
            <circle
              cx="50"
              cy="50"
              r={radius}
              fill="none"
              stroke="#F1F5F9"
              strokeWidth="9"
            />

            {/* Segments */}
            {segmentsWithOffsets.map((seg) => {
              if (seg.count === 0) return null;

              const isHovered = hoveredStatus === seg.status;

              return (
                <circle
                  key={seg.status}
                  cx="50"
                  cy="50"
                  r={radius}
                  fill="none"
                  stroke={seg.color}
                  strokeWidth={isHovered ? 12 : 9}
                  strokeDasharray={`${seg.segLen} ${circumference}`}
                  strokeDashoffset={mounted ? seg.currentOffset : baseOffset}
                  strokeLinecap={segmentsWithOffsets.filter((s) => s.count > 0).length === 1 ? 'butt' : 'round'}
                  className="transition-all duration-700 ease-out cursor-pointer hover:opacity-95"
                  onMouseEnter={() => setHoveredStatus(seg.status)}
                  onMouseLeave={() => setHoveredStatus(null)}
                  onClick={() => onNavigate && handleStatusClick(seg.status)}
                />
              );
            })}
          </svg>

          {/* Interactive Center Readout */}
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none transition-all duration-200">
            {activeSegment ? (
              <div className="text-center px-4 animate-view-entry">
                <span
                  className="text-2xl sm:text-3xl font-black block tracking-tight"
                  style={{ color: activeSegment.color }}
                >
                  {activeSegment.count}
                </span>
                <span className="text-[11px] font-extrabold uppercase tracking-wider text-slate-700 block">
                  {activeSegment.label}
                </span>
                <span className="text-[10px] font-semibold text-slate-400 block mt-0.5">
                  {activePercent}% of total
                </span>
              </div>
            ) : (
              <div className="text-center px-4">
                <span className="text-3xl sm:text-4xl font-black text-navy block tracking-tight">
                  {total}
                </span>
                <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 block mt-0.5">
                  Total Reports
                </span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Interactive Legend Grid */}
      <div className="pt-4 border-t border-slate-100">
        <div className={`grid grid-cols-1 ${segments.length === 4 ? 'sm:grid-cols-4' : 'sm:grid-cols-3'} gap-2.5`}>
          {segments.map((seg) => {
            const isHovered = hoveredStatus === seg.status;
            const segPercent = total > 0 ? Math.round((seg.count / total) * 100) : 0;

            return (
              <button
                key={seg.status}
                type="button"
                onClick={() => onNavigate && handleStatusClick(seg.status)}
                onMouseEnter={() => setHoveredStatus(seg.status)}
                onMouseLeave={() => setHoveredStatus(null)}
                className={`p-2.5 rounded-2xl border text-left transition-all duration-200 flex flex-col justify-between ${
                  isHovered
                    ? 'border-slate-300 bg-slate-50/90 shadow-xs -translate-y-0.5'
                    : 'border-slate-100 bg-slate-50/40 hover:bg-slate-50'
                } ${onNavigate ? 'cursor-pointer' : ''}`}
                title={onNavigate ? `Filter ${seg.label} reports in Explore` : undefined}
              >
                <div className="flex items-center justify-between gap-1 mb-1">
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-800">
                    <span
                      className={`w-2 h-2 rounded-full ${seg.dotColor} transition-transform ${
                        isHovered ? 'scale-125' : ''
                      }`}
                    />
                    {seg.label}
                  </span>
                  <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-white text-slate-500 border border-slate-200/60">
                    {segPercent}%
                  </span>
                </div>

                <div className="flex items-baseline justify-between mt-1">
                  <span className="text-base font-black text-navy">{seg.count}</span>
                  <span className="text-[10px] text-slate-400 truncate max-w-[90px]">
                    {seg.description.split(' ')[0]}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

    </div>
  );
};
