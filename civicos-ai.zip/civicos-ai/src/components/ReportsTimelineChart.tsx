import React, { useState } from 'react';
import { Issue, ViewType } from '../types';
import { Calendar, ArrowRight, Activity, Info } from 'lucide-react';

interface Props {
  issues: Issue[];
  onNavigate?: (view: ViewType) => void;
}

interface DayAggregate {
  dateKey: string; // YYYY-MM-DD
  displayDate: string; // e.g. "Oct 17"
  fullDate: string; // e.g. "Saturday, Oct 17, 2026"
  count: number;
  categories: { [cat: string]: number };
}

export const ReportsTimelineChart: React.FC<Props> = ({ issues, onNavigate }) => {
  const [hoveredDay, setHoveredDay] = useState<string | null>(null);

  // Filter issues with valid parseable timestamps
  const timestampedIssues = issues.filter((i) => {
    if (!i.created_at) return false;
    const d = new Date(i.created_at);
    return !isNaN(d.getTime());
  });

  if (timestampedIssues.length === 0) {
    return (
      <div className="bg-white rounded-3xl border border-slate-200/90 p-6 sm:p-7 shadow-[0_4px_20px_rgba(15,23,42,0.04)] text-center flex flex-col items-center justify-center space-y-2">
        <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-400">
          <Calendar className="w-5 h-5" />
        </div>
        <h3 className="text-sm font-bold text-slate-800">Report Activity Timeline</h3>
        <p className="text-xs text-slate-400 max-w-sm">
          No submission timestamps are currently available in the dataset. When dated reports are logged, an activity histogram will display here.
        </p>
      </div>
    );
  }

  // Aggregate issues strictly by calendar date (YYYY-MM-DD)
  const map: { [key: string]: DayAggregate } = {};

  timestampedIssues.forEach((issue) => {
    const d = new Date(issue.created_at);
    const dateKey = d.toISOString().split('T')[0];
    const displayDate = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    const fullDate = d.toLocaleDateString(undefined, {
      weekday: 'short',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });

    if (!map[dateKey]) {
      map[dateKey] = {
        dateKey,
        displayDate,
        fullDate,
        count: 0,
        categories: {},
      };
    }

    map[dateKey].count += 1;
    map[dateKey].categories[issue.category] = (map[dateKey].categories[issue.category] || 0) + 1;
  });

  // Sort chronological
  const timelineData = Object.values(map).sort((a, b) => a.dateKey.localeCompare(b.dateKey));
  const maxDayCount = Math.max(...timelineData.map((d) => d.count), 1);

  const activeDay = timelineData.find((d) => d.dateKey === hoveredDay);

  const startDate = timelineData[0]?.displayDate;
  const endDate = timelineData[timelineData.length - 1]?.displayDate;

  return (
    <div className="bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-7 shadow-[0_4px_20px_rgba(15,23,42,0.04)] hover:shadow-[0_8px_30px_rgba(15,23,42,0.07)] transition-all duration-300">
      
      {/* Header */}
      <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-teal/10 flex items-center justify-center text-teal">
              <Activity className="w-3.5 h-3.5 text-teal" />
            </div>
            <h3 className="text-sm sm:text-base font-black text-navy tracking-tight">
              Submission Activity Over Time
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Daily frequency of civic grievances registered by citizens
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200">
            {startDate === endDate ? startDate : `${startDate} – ${endDate}`}
          </span>
          <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-teal-50 text-teal border border-teal-200">
            {timestampedIssues.length} Total Logs
          </span>
        </div>
      </div>

      {/* Dynamic Hover Detail Tooltip */}
      <div className="min-h-[28px] mb-4 flex items-center">
        {activeDay ? (
          <div className="w-full px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs flex items-center justify-between animate-view-entry shadow-sm">
            <div className="flex items-center gap-2 flex-wrap">
              <Calendar className="w-3.5 h-3.5 text-[#A3E635]" />
              <span className="font-bold">{activeDay.fullDate}:</span>
              <span className="text-slate-300">
                {activeDay.count} {activeDay.count === 1 ? 'report submitted' : 'reports submitted'}
              </span>
              <span className="text-slate-400 text-[11px]">
                ({Object.entries(activeDay.categories)
                  .map(([cat, cnt]) => `${cat}: ${cnt}`)
                  .join(', ')})
              </span>
            </div>
            {onNavigate && (
              <span className="text-[#A3E635] text-[11px] font-semibold flex items-center gap-1">
                Explore Reports <ArrowRight className="w-3 h-3" />
              </span>
            )}
          </div>
        ) : (
          <div className="text-[11px] text-slate-400 italic flex items-center gap-1.5">
            <Info className="w-3 h-3 text-slate-400" />
            <span>Hover over any date column to view daily volume and category breakdown</span>
          </div>
        )}
      </div>

      {/* Column Histogram */}
      <div className="pt-2 pb-1">
        <div className="grid grid-cols-5 sm:grid-cols-5 md:grid-cols-5 gap-2 sm:gap-4 items-end min-h-[140px] px-2">
          {timelineData.map((day) => {
            const isHovered = hoveredDay === day.dateKey;
            // Height proportional to maximum day count (e.g. 1 out of 1 is 80% column height)
            const heightPercent = maxDayCount > 0 ? (day.count / maxDayCount) * 85 : 0;

            return (
              <div
                key={day.dateKey}
                onMouseEnter={() => setHoveredDay(day.dateKey)}
                onMouseLeave={() => setHoveredDay(null)}
                onClick={() => onNavigate && onNavigate('explore')}
                className={`flex flex-col items-center justify-end h-full group transition-all duration-200 ${
                  onNavigate ? 'cursor-pointer' : ''
                }`}
                title={`${day.fullDate}: ${day.count} reports`}
              >
                {/* Count Badge on Top of Bar */}
                <span
                  className={`text-xs font-black transition-all mb-1.5 ${
                    isHovered ? 'text-teal scale-110 font-black' : 'text-slate-700'
                  }`}
                >
                  {day.count}
                </span>

                {/* Column Track & Fill */}
                <div className="w-full max-w-[48px] h-28 bg-slate-100 rounded-2xl p-1 flex items-end justify-center shadow-inner">
                  <div
                    className={`w-full rounded-xl bg-gradient-to-t from-teal to-teal-400 transition-all duration-500 ease-out shadow-xs ${
                      isHovered
                        ? 'from-[#0D9488] to-[#A3E635] shadow-md brightness-110'
                        : 'opacity-90'
                    }`}
                    style={{
                      height: `${Math.max(heightPercent, 18)}%`,
                    }}
                  />
                </div>

                {/* Date Label */}
                <span
                  className={`text-[11px] font-bold mt-2 transition-colors text-center ${
                    isHovered ? 'text-teal' : 'text-slate-500'
                  }`}
                >
                  {day.displayDate}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Footer Meta */}
      <div className="pt-4 mt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
        <span>Interval: Daily actual submission logs ({timelineData.length} active dates)</span>
        {onNavigate && (
          <button
            type="button"
            onClick={() => onNavigate('explore')}
            className="font-bold text-teal hover:underline inline-flex items-center gap-1"
          >
            Inspect in Explore Desk &rarr;
          </button>
        )}
      </div>

    </div>
  );
};
