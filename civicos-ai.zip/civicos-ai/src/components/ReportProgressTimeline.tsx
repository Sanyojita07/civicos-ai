import React from 'react';
import { IssueStatus } from '../types';
import { Calendar, FileText, Check } from 'lucide-react';

interface Props {
  status: IssueStatus;
  createdAt: string;
}

export const ReportProgressTimeline: React.FC<Props> = ({ status, createdAt }) => {
  const formattedDate = (() => {
    try {
      const d = new Date(createdAt);
      return d.toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return createdAt;
    }
  })();

  // Order of standard issue progression
  const steps: { key: IssueStatus; label: string; desc: string }[] = [
    { key: 'Reported', label: 'Reported', desc: 'Received and registered in CivicOS database' },
    { key: 'Under Review', label: 'Under Review', desc: 'Being assessed by municipal responders' },
    { key: 'In Progress', label: 'In Progress', desc: 'Field teams and repair crews dispatched' },
    { key: 'Resolved', label: 'Resolved', desc: 'Remediation completed and verified' },
  ];

  const getStepState = (stepKey: IssueStatus) => {
    // Current database status mapping
    if (status === 'Resolved') {
      return 'completed';
    }
    if (status === 'In Progress') {
      if (stepKey === 'Reported' || stepKey === 'Under Review') return 'completed';
      if (stepKey === 'In Progress') return 'current';
      return 'upcoming';
    }
    if (status === 'Under Review') {
      if (stepKey === 'Reported') return 'completed';
      if (stepKey === 'Under Review') return 'current';
      return 'upcoming';
    }
    // 'Reported' or others
    if (stepKey === 'Reported') return 'current';
    return 'upcoming';
  };

  return (
    <div className="bg-slate-50/80 rounded-2xl border border-slate-200/90 p-5 sm:p-6">
      <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-200/70">
        <div>
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700">Official Progress Timeline</h4>
          <p className="text-[11px] text-slate-500 mt-0.5">
            Derived strictly from recorded submission timestamp and verified database status.
          </p>
        </div>
        <div className="flex items-center gap-1.5 text-xs font-medium text-slate-600 bg-white px-2.5 py-1 rounded-lg border border-slate-200">
          <Calendar className="w-3.5 h-3.5 text-teal" />
          <span>{formattedDate}</span>
        </div>
      </div>

      <div className="relative pl-6 sm:pl-8 space-y-6 before:absolute before:left-2.5 sm:before:left-3.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
        {steps.map((step) => {
          const state = getStepState(step.key);
          const isCurrent = state === 'current';
          const isCompleted = state === 'completed';

          return (
            <div key={step.key} className="relative group">
              {/* Dot Icon */}
              <div
                className={`absolute -left-6 sm:-left-8 top-0.5 w-5 h-5 rounded-full flex items-center justify-center transition-all ${
                  isCompleted
                    ? 'bg-emerald-500 text-white shadow-sm ring-4 ring-emerald-50'
                    : isCurrent
                    ? 'bg-teal text-white ring-4 ring-teal/20 pulse-indicator'
                    : 'bg-white border-2 border-slate-300 text-transparent'
                }`}
              >
                {isCompleted && <Check className="w-3 h-3 stroke-[3]" />}
                {isCurrent && <div className="w-1.5 h-1.5 bg-white rounded-full"></div>}
              </div>

              {/* Step Information */}
              <div>
                <div className="flex items-center gap-2">
                  <span
                    className={`text-xs font-bold ${
                      isCurrent
                        ? 'text-navy'
                        : isCompleted
                        ? 'text-slate-800'
                        : 'text-slate-400 font-medium'
                    }`}
                  >
                    {step.label}
                  </span>
                  {isCurrent && (
                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-teal/10 text-teal border border-teal/20">
                      Current Status
                    </span>
                  )}
                  {step.key === 'Reported' && (
                    <span className="text-[11px] text-slate-400 font-normal">
                      &bull; Logged: {formattedDate}
                    </span>
                  )}
                </div>
                <p
                  className={`text-[11px] mt-0.5 ${
                    isCurrent ? 'text-slate-600' : isCompleted ? 'text-slate-500' : 'text-slate-400'
                  }`}
                >
                  {step.desc}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-5 pt-3 border-t border-slate-200/70 flex items-center gap-2 text-[11px] text-slate-400">
        <FileText className="w-3.5 h-3.5 flex-shrink-0" />
        <span>Timeline dates are strictly sourced from database records without manufactured intermediate events.</span>
      </div>
    </div>
  );
};
