import React, { useEffect, useState } from 'react';
import { Issue, ViewType } from '../types';
import { Layers, ArrowRight, BarChart3 } from 'lucide-react';

interface Props {
  issues: Issue[];
  onNavigate?: (view: ViewType) => void;
}

interface CategoryConfig {
  category: string;
  gradient: string;
  dotColor: string;
  accent: string;
  badgeBg: string;
}

const CATEGORY_CONFIG: CategoryConfig[] = [
  {
    category: 'Garbage',
    gradient: 'from-amber-400 to-amber-500',
    dotColor: 'bg-amber-500',
    accent: '#F59E0B',
    badgeBg: 'bg-amber-50 text-amber-800 border-amber-200',
  },
  {
    category: 'Pothole/Road',
    gradient: 'from-orange-500 to-orange-600',
    dotColor: 'bg-orange-500',
    accent: '#F97316',
    badgeBg: 'bg-orange-50 text-orange-800 border-orange-200',
  },
  {
    category: 'Water Leakage',
    gradient: 'from-cyan-500 to-teal-600',
    dotColor: 'bg-cyan-500',
    accent: '#06B6D4',
    badgeBg: 'bg-cyan-50 text-cyan-800 border-cyan-200',
  },
  {
    category: 'Streetlight',
    gradient: 'from-yellow-400 to-amber-500',
    dotColor: 'bg-yellow-500',
    accent: '#EAB308',
    badgeBg: 'bg-yellow-50 text-yellow-800 border-yellow-200',
  },
  {
    category: 'Other',
    gradient: 'from-slate-400 to-slate-500',
    dotColor: 'bg-slate-400',
    accent: '#94A3B8',
    badgeBg: 'bg-slate-50 text-slate-700 border-slate-200',
  },
];

export const CategoryBarChart: React.FC<Props> = ({ issues, onNavigate }) => {
  const [mounted, setMounted] = useState(false);
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);

  useEffect(() => {
    // Smooth initial animation respecting preferences
    const timer = setTimeout(() => setMounted(true), 120);
    return () => clearTimeout(timer);
  }, []);

  const total = issues.length;

  const data = CATEGORY_CONFIG.map((cfg) => {
    const count = issues.filter((i) => i.category === cfg.category).length;
    const percent = total > 0 ? Math.round((count / total) * 100) : 0;
    return {
      ...cfg,
      count,
      percent,
    };
  });

  const handleCategoryClick = (categoryName: string) => {
    try {
      sessionStorage.setItem('civicos_filter_category', categoryName);
      sessionStorage.removeItem('civicos_filter_status');
    } catch {
      // sessionStorage safe fallback
    }
    if (onNavigate) {
      onNavigate('explore');
    }
  };

  if (total === 0) {
    return (
      <div className="bg-white rounded-3xl border border-slate-200/90 p-8 shadow-sm text-center flex flex-col items-center justify-center space-y-3">
        <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center text-slate-400">
          <Layers className="w-6 h-6" />
        </div>
        <div>
          <h3 className="text-sm font-bold text-slate-800">Reports by Category</h3>
          <p className="text-xs text-slate-500 mt-1 max-w-xs">
            No category reports are currently available to visualize. Once issues are submitted, category statistics will appear here.
          </p>
        </div>
      </div>
    );
  }

  const activeItem = data.find((d) => d.category === hoveredCategory);

  return (
    <div className="bg-white rounded-3xl border border-slate-200/90 p-5 sm:p-7 shadow-[0_4px_20px_rgba(15,23,42,0.04)] hover:shadow-[0_8px_30px_rgba(15,23,42,0.07)] transition-all duration-300 flex flex-col justify-between relative overflow-hidden">
      
      {/* Chart Header */}
      <div>
        <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-teal/10 flex items-center justify-center text-teal">
                <BarChart3 className="w-3.5 h-3.5 text-teal" />
              </div>
              <h3 className="text-sm sm:text-base font-black text-navy tracking-tight">
                Reports by Category
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Proportional distribution across municipal issue types
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-slate-100 text-slate-700 border border-slate-200/70">
              {total} Total
            </span>
            {onNavigate && (
              <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold text-teal bg-teal-50/80 px-2.5 py-1 rounded-full border border-teal-200/60">
                Click bar to filter
              </span>
            )}
          </div>
        </div>

        {/* Dynamic Tooltip Banner on Hover */}
        <div className="min-h-[28px] mb-3 flex items-center">
          {activeItem ? (
            <div className="w-full px-3 py-1.5 rounded-xl bg-slate-900 text-white text-xs flex items-center justify-between animate-view-entry shadow-sm">
              <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full ${activeItem.dotColor}`} />
                <span className="font-bold">{activeItem.category}:</span>
                <span className="text-slate-300">
                  {activeItem.count} {activeItem.count === 1 ? 'report' : 'reports'} ({activeItem.percent}%)
                </span>
              </div>
              {onNavigate && (
                <span className="text-[#A3E635] text-[11px] font-semibold flex items-center gap-1">
                  View in Explore <ArrowRight className="w-3 h-3" />
                </span>
              )}
            </div>
          ) : (
            <div className="text-[11px] text-slate-400 italic">
              Hover over a category bar for detailed metrics
            </div>
          )}
        </div>

        {/* Horizontal Bars List */}
        <div className="space-y-3.5">
          {data.map((item) => {
            const isHovered = hoveredCategory === item.category;
            // Proportional to total reports: 5 reports distributed equally = 20% each
            const barWidth = total > 0 ? (item.count / total) * 100 : 0;

            return (
              <div
                key={item.category}
                role={onNavigate ? 'button' : undefined}
                tabIndex={onNavigate ? 0 : undefined}
                onClick={() => onNavigate && handleCategoryClick(item.category)}
                onKeyDown={(e) => {
                  if (onNavigate && (e.key === 'Enter' || e.key === ' ')) {
                    e.preventDefault();
                    handleCategoryClick(item.category);
                  }
                }}
                onMouseEnter={() => setHoveredCategory(item.category)}
                onMouseLeave={() => setHoveredCategory(null)}
                className={`group p-2.5 -mx-2.5 rounded-2xl transition-all duration-200 ${
                  onNavigate ? 'cursor-pointer hover:bg-slate-50/90' : ''
                } ${isHovered ? 'bg-slate-50 shadow-xs' : ''}`}
                title={onNavigate ? `Filter ${item.category} reports in Explore` : undefined}
              >
                {/* Labels Row */}
                <div className="flex items-center justify-between text-xs mb-1.5">
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-2.5 h-2.5 rounded-full ${item.dotColor} transition-transform ${
                        isHovered ? 'scale-125 ring-2 ring-slate-300' : ''
                      }`}
                    />
                    <span
                      className={`font-bold transition-colors ${
                        isHovered ? 'text-teal' : 'text-slate-700'
                      }`}
                    >
                      {item.category}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-slate-900">
                      {item.count}
                    </span>
                    <span className="text-[11px] font-semibold text-slate-400 min-w-[36px] text-right">
                      {item.percent}%
                    </span>
                    {onNavigate && (
                      <ArrowRight
                        className={`w-3.5 h-3.5 text-slate-400 group-hover:text-teal group-hover:translate-x-0.5 transition-all opacity-0 group-hover:opacity-100 hidden sm:block`}
                      />
                    )}
                  </div>
                </div>

                {/* Proportional Bar Track */}
                <div className="w-full h-3 sm:h-3.5 bg-slate-100 rounded-full overflow-hidden p-0.5 shadow-inner">
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${item.gradient} transition-all duration-1000 ease-out shadow-xs ${
                      isHovered ? 'brightness-110 shadow-sm' : ''
                    }`}
                    style={{
                      width: mounted
                        ? `${Math.max(barWidth, item.count > 0 ? 4 : 0)}%`
                        : '0%',
                    }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Footer Meta / Hint */}
      <div className="pt-4 mt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
        <span>Scale: Proportional to total reports ({total})</span>
        {onNavigate && (
          <button
            type="button"
            onClick={() => onNavigate('explore')}
            className="font-bold text-teal hover:underline inline-flex items-center gap-1"
          >
            Explore all categories &rarr;
          </button>
        )}
      </div>

    </div>
  );
};
