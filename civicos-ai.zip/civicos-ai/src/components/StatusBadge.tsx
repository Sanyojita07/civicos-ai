import React from 'react';
import { IssueStatus } from '../types';
import { AlertCircle, Clock, CheckCircle2, Search } from 'lucide-react';

interface Props {
  status: IssueStatus;
}

export const StatusBadge: React.FC<Props> = ({ status }) => {
  switch (status) {
    case 'Reported':
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-50 text-amber-800 border border-amber-200/90 shadow-[0_1px_2px_rgba(245,158,11,0.06)]">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 pulse-indicator"></span>
          <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
          <span>Reported</span>
        </span>
      );
    case 'Under Review':
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-800 border border-indigo-200/90 shadow-[0_1px_2px_rgba(99,102,241,0.06)]">
          <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 pulse-indicator"></span>
          <Search className="w-3.5 h-3.5 text-indigo-600" />
          <span>Under Review</span>
        </span>
      );
    case 'In Progress':
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-teal-50 text-teal-800 border border-teal-200/90 shadow-[0_1px_2px_rgba(13,148,136,0.06)]">
          <span className="w-1.5 h-1.5 rounded-full bg-teal pulse-indicator"></span>
          <Clock className="w-3.5 h-3.5 text-teal" />
          <span>In Progress</span>
        </span>
      );
    case 'Resolved':
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-50 text-emerald-800 border border-emerald-200/90 shadow-[0_1px_2px_rgba(16,185,129,0.06)]">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
          <span>Resolved</span>
        </span>
      );
    default:
      return (
        <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-semibold bg-slate-100 text-slate-700">
          {status}
        </span>
      );
  }
};
