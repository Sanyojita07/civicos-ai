import React from 'react';
import { Issue } from '../types';
import { StatusBadge } from './StatusBadge';
import { MapPin, Calendar, Trash2, Construction, Droplet, Lightbulb, HelpCircle } from 'lucide-react';

interface Props {
  issue: Issue;
  isDemo?: boolean;
}

const getCategoryMeta = (category: string) => {
  switch (category) {
    case 'Garbage':
      return {
        icon: <Trash2 className="w-3.5 h-3.5 text-amber-600" />,
        badgeBg: 'bg-amber-50 text-amber-800 border-amber-200/80',
        cardAccent: 'hover:border-amber-300',
      };
    case 'Pothole/Road':
      return {
        icon: <Construction className="w-3.5 h-3.5 text-orange-600" />,
        badgeBg: 'bg-orange-50 text-orange-800 border-orange-200/80',
        cardAccent: 'hover:border-orange-300',
      };
    case 'Water Leakage':
      return {
        icon: <Droplet className="w-3.5 h-3.5 text-cyan-600" />,
        badgeBg: 'bg-cyan-50 text-cyan-800 border-cyan-200/80',
        cardAccent: 'hover:border-cyan-300',
      };
    case 'Streetlight':
      return {
        icon: <Lightbulb className="w-3.5 h-3.5 text-yellow-600" />,
        badgeBg: 'bg-yellow-50 text-yellow-800 border-yellow-200/80',
        cardAccent: 'hover:border-yellow-300',
      };
    default:
      return {
        icon: <HelpCircle className="w-3.5 h-3.5 text-slate-600" />,
        badgeBg: 'bg-slate-100 text-slate-700 border-slate-200',
        cardAccent: 'hover:border-slate-300',
      };
  }
};

export const IssueCard: React.FC<Props> = ({ issue, isDemo }) => {
  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString(undefined, {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
      });
    } catch {
      return dateString;
    }
  };

  const meta = getCategoryMeta(issue.category);

  return (
    <div className={`group bg-white rounded-2xl border border-slate-200/80 shadow-[0_2px_8px_rgba(15,23,42,0.04)] hover:shadow-[0_12px_28px_rgba(15,23,42,0.08)] motion-card flex flex-col justify-between p-5 sm:p-6 w-full ${meta.cardAccent}`}>
      <div>
        {/* Top Badges */}
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-1.5">
            <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-semibold border ${meta.badgeBg}`}>
              {meta.icon}
              <span>{issue.category}</span>
            </span>
            {isDemo && (
              <span className="text-xs uppercase tracking-wider font-semibold text-slate-400 bg-slate-100/80 px-2 py-0.5 rounded border border-slate-200">
                Sample
              </span>
            )}
          </div>
          <StatusBadge status={issue.status} />
        </div>

        {/* Title */}
        <h3 className="text-base font-bold text-navy group-hover:text-teal transition-colors line-clamp-2 leading-snug mb-2">
          {issue.title}
        </h3>

        {/* Description */}
        <p className="text-xs text-slate-600 mb-5 line-clamp-3 leading-relaxed whitespace-pre-line">
          {issue.description}
        </p>
      </div>

      {/* Footer Info */}
      <div className="pt-3.5 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-500">
        <div className="flex items-center gap-1.5 font-medium text-slate-700 max-w-[65%] truncate bg-slate-50 px-2.5 py-1 rounded-md border border-slate-100">
          <MapPin className="w-3.5 h-3.5 text-teal flex-shrink-0" />
          <span className="truncate" title={issue.location}>{issue.location}</span>
        </div>
        <div className="flex items-center gap-1 text-slate-400">
          <Calendar className="w-3.5 h-3.5" />
          <span>{formatDate(issue.created_at)}</span>
        </div>
      </div>
    </div>
  );
};
