import React from 'react';

export const CitySkylineIllustration: React.FC<{ className?: string }> = ({ className = "w-full h-auto text-slate-700/40" }) => (
  <svg
    viewBox="0 0 1200 240"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    preserveAspectRatio="none"
  >
    <defs>
      <linearGradient id="skylineGrad" x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#0D9488" stopOpacity="0.25" />
        <stop offset="100%" stopColor="#0F172A" stopOpacity="0.02" />
      </linearGradient>
      <linearGradient id="glowGrad" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stopColor="#0D9488" stopOpacity="0.2" />
        <stop offset="50%" stopColor="#A3E635" stopOpacity="0.4" />
        <stop offset="100%" stopColor="#0D9488" stopOpacity="0.2" />
      </linearGradient>
      <linearGradient id="beaconBeam" x1="0%" y1="100%" x2="0%" y2="0%">
        <stop offset="0%" stopColor="#A3E635" stopOpacity="0.6" />
        <stop offset="100%" stopColor="#A3E635" stopOpacity="0" />
      </linearGradient>
    </defs>

    {/* Background silhouettes */}
    <rect x="40" y="90" width="70" height="150" fill="currentColor" fillOpacity="0.15" rx="3" />
    <rect x="130" y="50" width="90" height="190" fill="currentColor" fillOpacity="0.2" rx="4" />
    <polygon points="175,20 160,50 190,50" fill="currentColor" fillOpacity="0.25" />
    <rect x="240" y="110" width="60" height="130" fill="currentColor" fillOpacity="0.15" rx="3" />
    <rect x="320" y="70" width="85" height="170" fill="currentColor" fillOpacity="0.22" rx="3" />
    
    {/* Center landmark buildings */}
    <rect x="430" y="40" width="110" height="200" fill="url(#skylineGrad)" stroke="#0D9488" strokeOpacity="0.3" strokeWidth="1" rx="4" />
    
    {/* Animated glowing windows */}
    <line x1="450" y1="65" x2="455" y2="65" stroke="#A3E635" strokeOpacity="0.7" strokeWidth="2.5" strokeLinecap="round" className="animate-pulse-window" />
    <line x1="475" y1="65" x2="480" y2="65" stroke="#A3E635" strokeOpacity="0.6" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="505" y1="65" x2="510" y2="65" stroke="#A3E635" strokeOpacity="0.8" strokeWidth="2.5" strokeLinecap="round" className="animate-pulse-window-delayed" />
    
    <line x1="450" y1="85" x2="455" y2="85" stroke="#A3E635" strokeOpacity="0.5" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="475" y1="85" x2="480" y2="85" stroke="#A3E635" strokeOpacity="0.85" strokeWidth="2.5" strokeLinecap="round" className="animate-pulse-window" />
    <line x1="505" y1="85" x2="510" y2="85" stroke="#A3E635" strokeOpacity="0.4" strokeWidth="2.5" strokeLinecap="round" />
    
    <line x1="450" y1="105" x2="455" y2="105" stroke="#A3E635" strokeOpacity="0.75" strokeWidth="2.5" strokeLinecap="round" className="animate-pulse-window-delayed" />
    <line x1="475" y1="105" x2="480" y2="105" stroke="#A3E635" strokeOpacity="0.8" strokeWidth="2.5" strokeLinecap="round" />
    <line x1="505" y1="105" x2="510" y2="105" stroke="#A3E635" strokeOpacity="0.65" strokeWidth="2.5" strokeLinecap="round" className="animate-pulse-window" />

    {/* Tower spire and beacon pulse */}
    <line x1="485" y1="12" x2="485" y2="40" stroke="#0D9488" strokeWidth="2" />
    <circle cx="485" cy="10" r="3.5" fill="#A3E635" className="animate-beacon" />
    <circle cx="485" cy="10" r="8" stroke="#A3E635" strokeWidth="1" strokeOpacity="0.5" className="animate-beacon-ring" />

    {/* Right buildings */}
    <rect x="560" y="80" width="75" height="160" fill="currentColor" fillOpacity="0.2" rx="3" />
    <rect x="655" y="45" width="105" height="195" fill="currentColor" fillOpacity="0.25" rx="4" />
    <polygon points="707,15 690,45 725,45" fill="currentColor" fillOpacity="0.3" />
    
    <rect x="780" y="100" width="65" height="140" fill="currentColor" fillOpacity="0.15" rx="3" />
    <rect x="865" y="60" width="95" height="180" fill="currentColor" fillOpacity="0.2" rx="4" />
    <rect x="980" y="115" width="70" height="125" fill="currentColor" fillOpacity="0.14" rx="3" />
    <rect x="1070" y="85" width="80" height="155" fill="currentColor" fillOpacity="0.18" rx="3" />

    {/* Road and animated civic transmission grid */}
    <line x1="0" y1="238" x2="1200" y2="238" stroke="url(#glowGrad)" strokeWidth="3" />
    <line
      x1="0"
      y1="230"
      x2="1200"
      y2="230"
      stroke="#0D9488"
      strokeOpacity="0.3"
      strokeWidth="1.5"
      strokeDasharray="8 12"
      className="animate-grid-flow"
    />
  </svg>
);
